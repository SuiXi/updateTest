
require "Cocos2d"

-- cclog
cclog = function(...)
    print(string.format(...))
end
local K_ACTOR_STATE_RUN = 1

G_IS_ONLINE = false
local Net = nil

-- for CCLuaEngine traceback
function __G__TRACKBACK__(msg)
    cclog("----------------------------------------")
    cclog("LUA ERROR: " .. tostring(msg) .. "\n")
    cclog(debug.traceback())
    cclog("----------------------------------------")
    return msg
end
--[[--
* 核心循环
]]
local function logic( dt )
    -- print("logic")
    Net:logic(dt)
end

local function main()
    collectgarbage("collect")
    -- avoid memory leak
    collectgarbage("setpause", 100)
    collectgarbage("setstepmul", 5000)

    cc.FileUtils:getInstance():addSearchPath("src")
    cc.FileUtils:getInstance():addSearchPath("res")

    -- initialize director
    local director = cc.Director:getInstance()

    --turn on display FPS
    director:setDisplayStats(true)

    --set FPS. the default value is 1.0/60 if you don't call this
    director:setAnimationInterval(1.0 / 60.0)
    
    local glView = director:getOpenGLView()
    local designSize = {width = 960, height = 640}
    glView:setDesignResolutionSize(designSize.width, designSize.height, cc.ResolutionPolicy.FIXED_HEIGHT)

    -- ===============加载一些lua文件============================
    require "CCBReaderLoad"

    require("xx.xx")
    require("xx.const")

    -- ===========================================
    Net = require("net.Net")

    local gameScene = xx.Scene

    -- local layer = require("battle.WarLayer"):create()
    -- local layer = require("view.WebTestLayer").new()
    -- gameScene:pushLayer(require("view.MainLayer"):create())
    gameScene:pushLayer(require("base.UpdateLayer"):create())

    

    if cc.Director:getInstance():getRunningScene() then
        cc.Director:getInstance():replaceScene(gameScene)
    else
        cc.Director:getInstance():runWithScene(gameScene)
    end

    --create scene 
    
    ------------------网络相关----------------------


    --======================网络循环=======end======================
    if G_IS_ONLINE then

        gameScene:scheduleUpdateWithPriorityLua(logic, 0)
    end
    --======================链接网络=======end======================
    ----------------------------------------

    --   cclog( string.l("多语言测试"))
    --   cclog( string.l("请稍后"))
    --   cclog( string.l("请稍后"))
    --   cclog( string.l("nihao"))
    --   cclog( string.l("请稍后"))
    --   cclog( string.l("请稍后"))
    --   cclog( string.l("获取圣剑"))
    --   xx.printLang()
    --======================关于战斗的=============================
    -- xx.war = require("battle.War")
    -- -- war:setWarLayer(layer)
    -- xx.war:init(layer)
    --======================关于战斗的=======end======================

    -- m_rankGift = Common::setBitValue(index,value,m_rankGift);
    --
    -- return Common::isBitValue(index,m_rankGift);

    local k_is_a = bit.lshift(1,1)
    local k_is_b = bit.lshift(1,2)
    local k_is_c = bit.lshift(1,3)
    local m_rankGift = bit.tobit(1)
    -- local x = bit.bor(status,k_is_c)
    -- print("x = " ..x)
    -- setBitValueTable
    print("status_b = " .. tostring(xx.isBitValue(k_is_b,m_rankGift)))
    m_rankGift = xx.setBitValue(k_is_b,true,m_rankGift)
    print("status_b = " .. tostring(xx.isBitValue(k_is_b,m_rankGift)))
     m_rankGift = xx.setBitValue(k_is_b,false,m_rankGift)
    print("status_b = " .. tostring(xx.isBitValue(k_is_b,m_rankGift)))
 

    -- local x = BIT_INDEX_1
    -- local x = BIT_INDEX_1
    -- local x = BIT_INDEX_1
--    local const = require("xx.const")
--    local x = const.BIT_INDEX_1
--    print(x,const.BIT_INDEX_1)
--    x = 4 
--    print(x,const.BIT_INDEX_1)
end


local status, msg = xpcall(main, __G__TRACKBACK__)
if not status then
    error(msg)
end
