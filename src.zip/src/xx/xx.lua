--[[--
 * 工具类
 * @Author:      JuhnXu
 * @DateTime:    2015-04-02 18:16:01

 ]]
require "bit"

xx = {}
--Jx ======================多语言化================================
local lang = require("lang.lang_cn") 

function xx.autoLocal( str )

	if not lang[str] then
	
		lang[str] = str
	end
		return lang[str]

end
--[[--
 * 打印当前缓存的表,复制控制台信息到lang就好  
 ]]
function xx.printLang(  )
	cclog(xx.serialize(lang))
end
--[[--
 * 改变本地语言  
 * @param     str 语言类型 cn,en等
 * @return    
 ]]
function xx.changeLang( str )
	local temp = require("lang.lang_"..str)
	if temp then
		lang = temp
	end
end
string.l = xx.autoLocal
-- ======================多语言化================================

--Jx ======================bit处理================================


--[[--  
 * @param   int index 	掩码
 			bool status 修正值
 			int value 	待修改的值
 Ps.注意要重新设置返回值
 如下:
  value = xx.setBitValue(k_is_b,false,value)
  因为在lua中 table，userdata,lightuserdata传引用，其它传值
 ]]
function xx.setBitValue( index, status, value )

	if status then
		
		return bit.bor(value,index)
	else
		return bit.band(value,bit.bnot(index))
	end
	
end

function xx.isBitValue( index, value )

	return bit.band(value,index) ~= 0
end
-- ======================bit处理==end==============================
-- ======================tool一些工具================================
 
--[[--
 * 序列化打印table表  
 * @param     t table表
 ]]
function xx.serialize(t)
    local mark={}
    local assign={}

    local function ser_table(tbl,parent)
        mark[tbl]=parent
        local tmp={}
        for k,v in pairs(tbl) do
            local key= type(k)=="number" and "["..k.."]" or k
            if type(v)=="table" then
                local dotkey= parent..(type(k)=="number" and key or "."..key)
                if mark[v] then
                    table.insert(assign,dotkey.."="..mark[v])
                else
                    table.insert(tmp, key.."="..ser_table(v,dotkey))
                end
            else
                v = v or "" --判断空值

                if type(v) == "boolean" then --判断布尔值

                    v =  v and "true" or "false"
                    table.insert(tmp, "\t"..key.." = "..v )

                else --字符串

                    table.insert(tmp, "\t"..key.." = \""..v .."\"")
                end

            end
        end
        return "\n"..table.concat(tmp,",\n").."\n"
    end

    return " return {\n"..ser_table(t,"ret").."\n}"  

end 
xx.vd = xx.serialize
--[[--

如果对象是指定类或其子类的实例，返回 true，否则返回 false

~~~ lua

local Animal = class("Animal")
local Duck = class("Duck", Animal)

print(iskindof(Duck.new(), "Animal")) -- 输出 true

~~~

@param mixed obj 要检查的对象
@param string classname 类名

@return boolean

]]
function xx.iskindof(obj, classname)
    local t = type(obj)
    local mt
    if t == "table" then
        mt = getmetatable(obj)
    elseif t == "userdata" then
        mt = tolua.getpeer(obj)
    end

    while mt do
        if mt.__cname == classname then
            return true
        end
        mt = mt.super
    end

    return false
end


--[[--
* --JuhnXu's Tool just to debug,用于即时调试信息的工具
* 传入要调试的layer,在layer上添加个输入框
* @Author:      JuhnXu
* @DateTime:    2015-02-10 17:26:09
* eg.
    
    addDebugTool(self) --调用一次就好
    --添加命令例子
    addCmd("greet",function ()
        cclog("hi,my name is JuhnXu")
    end)
    --添加默认方法,Ps. function 必须要有cmd参数
    addDefaultCmd( function (cmd)
        cclog("hi,my name is JuhnXu %s" , cmd)
    end)
]]
--命令集合
local cmds = {}

function xx.addDebugTool(self)

    local cmd_box = nil
    cmd_box = cc.EditBox:create(cc.size(174, 69), cc.Scale9Sprite:create("btn_cmd.png"))
    cmd_box:setPosition(cc.p(cc.Director:getInstance():getWinSize().width - 174,50))
    cmd_box:setReturnType(cc.KEYBOARD_RETURNTYPE_DONE )

    local function editBoxTextEventHandle(strEventName,pSender)

        if strEventName == "changed" then
            local cmd = pSender:getText()
            cclog("cmd = " .. cmd)

            if tonumber(cmd) then --如果是数字的话
                -- cclog("num is " .. tonumber(cmd))
                -- self:setPage(tonumber(cmd))
                return
            end

            local flag = false

            for key, f in pairs(cmds) do
                if key == cmd then
                    f()
                    flag = true
                    break
                end
            end

            if not flag then
                cmds["default"](cmd)
            end
        end
    end

    cmd_box:registerScriptEditBoxHandler(editBoxTextEventHandle)
    self:addChild(cmd_box)
    --最好别修改上面方法====================================================================

end

function xx.addCmd( key, func )
    
    if key then
        -- table.insert(cmds,)
        cmds[key] = func
    end

end

function xx.addDefaultCmd(  func )
    
    cmds["default"] = func
end


--====================================================================
--======================关于ccnode的clone方法==============================================

--[[--
 * todo 完成一个基于ccb的copy的方法  未完成
 * @param     
 * @return    
 ]]
 function xx.getClone( node )
     
 end
--====================================================================


--[[--
 * 转换出16进制  
 * @param     
 * @return    
 ]]
function xx.hex(s)
 s=string.gsub(s,"(.)",function (x) return string.format("%02X",string.byte(x)) end)
 return s
end
-- ======================tool一些工具==end==============================

-- ======================一些希望全局访问的属性==例如war==============================
xx.war = nil


xx.Scene = require("base.XXScene")
xx.Layer = require("base.XXLayer")
xx.curLayer = nil --当前显示的Layer , Ps.在Layer:init()方法中hw.curLayer是不存在或者指向上一层的,因为当前layer还没完全生成
-- ======================一些希望全局访问的属性==end==============================
