--[[--
 * 存放军队初始化阵型
 * @Author:      JuhnXu
 * @DateTime:    2015-04-04 17:10:01
 ]]
 return {

 	army_l = {
            [1] = {id = 12111, level = 1, soldierNum = 16},
            [2] = {id = 12211, level = 1, soldierNum = 16},
            [3] = {id = 12511, level = 1, soldierNum = 16},
            [4] = {id = 12511, level = 1, soldierNum = 16},
            [5] = {id = 12511, level = 1, soldierNum = 16},
            [6] = {id = 12611, level = 1, soldierNum = 16}, 
            [7] = {id = 12111, level = 1, soldierNum = 16},
            [8] = {id = 12211, level = 1, soldierNum = 16},
            [9] = {id = 12511, level = 1, soldierNum = 16},
            [10] = {id = 12511, level = 1, soldierNum = 16},
            [11] = {id = 12511, level = 1, soldierNum = 16},
            [12] = {id = 12611, level = 1, soldierNum = 16},
            [13] = {id = 12111, level = 1, soldierNum = 16},
            [14] = {id = 12211, level = 1, soldierNum = 16},
            [15] = {id = 12511, level = 1, soldierNum = 16},

            [16] = {id = 12311, level = 1, soldierNum = 16},
            [17] = {id = 12311, level = 1, soldierNum = 16},
            [18] = {id = 12411, level = 1, soldierNum = 16},
            [19] = {id = 12311, level = 1, soldierNum = 16},
            [20] = {id = 12411, level = 1, soldierNum = 16},
	 },
	 army_r = {
            [1] = {id = 12111, level = 1, soldierNum = 16},
            [2] = {id = 12211, level = 1, soldierNum = 16},
            [3] = {id = 12511, level = 1, soldierNum = 16},
            [4] = {id = 12511, level = 1, soldierNum = 16},
            [5] = {id = 12511, level = 1, soldierNum = 16},
            [6] = {id = 12611, level = 1, soldierNum = 16}, 
            [7] = {id = 12111, level = 1, soldierNum = 16},
            [8] = {id = 12211, level = 1, soldierNum = 16},
            [9] = {id = 12511, level = 1, soldierNum = 16},
            [10] = {id = 12511, level = 1, soldierNum = 16},
            [11] = {id = 12511, level = 1, soldierNum = 16},
            [12] = {id = 12611, level = 1, soldierNum = 16},
            [13] = {id = 12111, level = 1, soldierNum = 16},
            [14] = {id = 12211, level = 1, soldierNum = 16},
            [15] = {id = 12511, level = 1, soldierNum = 16},
            
            [16] = {id = 12311, level = 1, soldierNum = 16},
            [17] = {id = 12311, level = 1, soldierNum = 16},
            [18] = {id = 12411, level = 1, soldierNum = 16},
            [19] = {id = 12311, level = 1, soldierNum = 16},
            [20] = {id = 12411, level = 1, soldierNum = 16}, 
	}

}