--[[--
 * 存放常量,要用的时候require
 * @Author:      JuhnXu
 * @DateTime:    2015-04-04 17:10:01
 ]]
 return {
 -- bit
	 BIT_INDEX_1 = bit.lshift(1,1),
	 BIT_INDEX_2 = bit.lshift(1,2),
	 BIT_INDEX_3 = bit.lshift(1,3),
	 BIT_INDEX_4 = bit.lshift(1,4),
	 BIT_INDEX_5 = bit.lshift(1,5),
	 BIT_INDEX_6 = bit.lshift(1,6),
	 BIT_INDEX_7 = bit.lshift(1,7),
	 BIT_INDEX_8 = bit.lshift(1,8),
	 BIT_INDEX_9 = bit.lshift(1,9),
	 BIT_INDEX_10 = bit.lshift(1,10), 
	 BIT_INDEX_11 = bit.lshift(1,11), 
	 BIT_INDEX_12 = bit.lshift(1,12), 
	 BIT_INDEX_13 = bit.lshift(1,13), 
	 BIT_INDEX_14 = bit.lshift(1,14), 

}