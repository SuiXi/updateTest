--[[--
* 角色基类
小兵不需要在意那个是敌方还是我方,只需要听从team的指挥就好
team指派 移动的目的地 和 攻击的目标 (也可以强制待机,不过一般待机和死亡都是自身操作)
* @Author:      JuhnXu
* @DateTime:    2015-04-04 13:06:16
]]
local const = require("xx.const")
local ActorList = require("config.ActorList")

-- 全局兵的id,每次游戏都会产生独一无二的兵
local total_chess_id_ = 1

-- 状态
local K_ACTOR_STATE_RUN = const.BIT_INDEX_1 --路径修正中, 最优先操作
local K_ACTOR_STATE_DIE = const.BIT_INDEX_2
local K_ACTOR_STATE_HURT = const.BIT_INDEX_3
local K_ACTOR_STATE_STAND = const.BIT_INDEX_4
local K_ACTOR_STATE_ATTACK = const.BIT_INDEX_5
-- local K_ACTOR_STATE_FIX = const.BIT_INDEX_6

-- 阵型
local K_ACTOR_STATE_IS_R = const.BIT_INDEX_5

-- 特殊状态,冲锋,暴怒等
local K_ACTOR_STATE_CHARGE = const.BIT_INDEX_6
local K_ACTOR_STATE_FURG = const.BIT_INDEX_7
local K_ACTOR_STATE_SLOW = const.BIT_INDEX_8

local k_attacking_pos = { --获得多角恋时站位的位置,考虑废弃,
    cc.p(-50,0),
    cc.p(100,0),
    cc.p(0,50),
    cc.p(0,-50),
}

local CCP_ZERO = cc.p(0,0)

local Actor = class("Actor")

function Actor:ctor(  )

end
--[[--
* 初始化兵种的信息,
* @param  name 兵种的称号
* @return
]]
function Actor:init( name )

    local lib = ActorList[name]

    if not lib then
        cclog("error:未知兵种")
        --设想是否要预留接口,用以兼容以后的版本
        return
    end
    -- actor_a1 = {blood = 100,speed = 50,damage = 20,money = 10,range =5}
    self.name = name
    self.blood = lib.blood
    self.speed = lib.speed
    self.damage = lib.damage
    self.money = lib.money
    self.delay = 5 --攻击间隔
    self.range = lib.range

    total_chess_id_ = total_chess_id_ + 1

    self.id = total_chess_id_

    --图形节点
    self.sp = cc.Sprite:create(string.format("actor/%s.png",self.name))

    -- 关于战斗状态的
    self.atk_count = 0
    self.target = nil       --攻击单位
    self.targeted = {}      --被攻击列表
    self.arr_num = 1        --我是第几个上ta的人?
    self.fix_pos = CCP_ZERO        --下次移动的目的地
    self.flip_arg = 1

    --状态,初始化设定成待机状态
    self.state = 0
    self:stand()

    return self
end

--[[--
* 克隆一个Actor
]]
function Actor:clone( actor )
    local act = Actor.new()
    self.name = actor.name
    self.blood = actor.blood
    self.speed = actor.speed
    self.damage = actor.damage
    self.money = actor.money
    self.delay = actor.delay --攻击间隔
    self.range = actor.range

    total_chess_id_ = total_chess_id_ + 1
    self.id = total_chess_id_

    self.state = 0

    --图形节点
    self.sp = cc.Sprite:create(string.format("actor/%s.png",self.name))
end
--[[--
* 获取图形节点
* @param
* @return
]]
function Actor:getNode(  )
    return self.sp
end

function Actor:create( name )

    local actor = Actor.new(name)

    return actor:init(name)
end

--[[--
* 根据state采取动作
* @param
* @return
]]
function Actor:action( dt )

    -- 1.如果死亡的话不执行更新了
    -- 2.如果是待机状态,并且没找到目标就保持待机吧
    --   2.a如果找到目标的话就切换成run状态
    -- 3.如果是攻击状态的话 就保持攻击
    --  3.a如果目标不存在的话 就切换成待机状态
    -- 4.如果是run状态的话,如果在射程之内,切换成攻击状态
    -- 4.a如果不在射程之内,继续run
    -- 4.b如果run的时候目标死亡了,切换成待机
    if self:isDie() then
        -- 单位已经死亡
        cclog("单位"..self.id.."已经死亡")
        return
    end

    -- *.大前提,如果没目标,不断去找目标,如果还是没的话都切换成stand()
    if not self.target then

        -- xx.war:getTarget(self)
        -- 这里不获得目标,由team设置
        self:getNode():setColor(cc.c3b(255,255,255))
        self:stand() --没目标都要切换成待机状态,就算找到目标也站立一个回合

        return
    end

    --以下都是有目标的====================================================
    --如果是待机状态,a如果找到目标的话就取消待机状态切换成run状态
    if xx.isBitValue(K_ACTOR_STATE_STAND,self.state) then

        self.state = xx.setBitValue(K_ACTOR_STATE_STAND,false,self.state)
        self.state = xx.setBitValue(K_ACTOR_STATE_RUN,true,self.state)

        return
    end

    -- 4.如果是run状态的话,如果在射程之内,取消Run状态切换成攻击状态
    if xx.isBitValue(K_ACTOR_STATE_RUN,self.state) then
        -- 在射程之内
        if self:isInRange() then
            self:getNode():setColor(cc.c3b(255,0,0))
            self.state = xx.setBitValue(K_ACTOR_STATE_RUN,false,self.state)
            self.state = xx.setBitValue(K_ACTOR_STATE_ATTACK,true,self.state)

        else --4.a如果不在射程之内,继续run
            self:run()
        end

        return
    end

    -- 3.如果是攻击状态的话 就保持攻击
    if xx.isBitValue(K_ACTOR_STATE_ATTACK,self.state) then
        self:attack()
        return
    end

end

--[[--
* 士兵的状态更新
-- *.如果自身死亡,跳过update
-- *.检测并且处理身上的效果,减速或者buff等
-- 1.如果是未接近目标的时候,切换成run的状态,接近目标(如果是目标第二个攻击者应该设置成另一个方向的目标)
-- 2.如果目标是攻击范围之内,切换成攻击状态(如果目标走开也会切换成run的状态)
-- *.攻击累加次数,判断是否发动攻击,以及几率发动技能效果(虽然也许小兵没有技能效果,但是预留先)
-- 3.如果目标死亡,设置target = nil ,再寻找目标
-- 4.如果自身死亡,设置target = nil ,并且清除target的被攻击列表中的自己
* @param
* @return
]]
function Actor:update(  )

    -- *.如果自身死亡,跳过update
    if xx.isBitValue(K_ACTOR_STATE_DIE,self.state) then
        return
    end

    local sp = self:getNode()
    local x,y = sp:getPosition()

    -- *.检测并且处理身上的效果,减速或者buff等===============================================================================

    local offset = 0

    if xx.isBitValue(K_ACTOR_STATE_SLOW,self.state)  then --减速状态

        offset = self.delay *2
    else
        offset = self.delay
    end
    -- 1.如果是未接近目标的时候,切换成run的状态,接近目标(如果是目标第二个攻击者应该设置成另一个方向的目标)
    -- 2.如果目标是攻击范围之内,切换成攻击状态(如果目标走开也会切换成run的状态)
    if not self.target then
        return
    end
    -- self:moveOrAttack()

    -- 处理攻击逻辑===============================================================================

    if xx.isBitValue(K_ACTOR_STATE_ATTACK,self.state) and self.target then

        self.atk_count = self.atk_count +1

        if self.atk_count >= offset then --到攻击帧
            cclog(self.id .."攻击")
            self.atk_count = 0 --清空攻击次数,要重新累计

            self:attack()
            self.target:hurtBy(self)
            --            cclog("close id = " .. Controller:getChessByClosed(self).id)
        else
        --原地待机
        -- self:stand()
        end
    end


    -- ===============================================================================

end

function Actor:getBuff(  )
    
    local offset = 0

    if xx.isBitValue(K_ACTOR_STATE_SLOW,self.state)  then --减速状态

        offset = self.delay *2
    else
        offset = self.delay
    end

    return offset
end

function Actor:attack(  )
    --    cclog("attack")
    if not self.target then
        return
    end

    self.atk_count = self.atk_count +1

    local offset = self:getBuff()
    
    if self.atk_count >= offset then --到攻击帧
        cclog(self.id .."攻击")
        self.atk_count = 0 --清空攻击次数,要重新累计

        --
        -- =================临时动画效果==============================================================

        local sp = self:getNode()
        local x,y = sp:getPosition()
        local action = cc.MoveBy:create(0.1,cc.p(50,0))

        sp:runAction(cc.Sequence:create(action,action:reverse()))
        -- ===============================================================================

        self.target:hurtBy(self)
    else
    --原地待机
    -- self:stand()
    end


end

function Actor:setTarget( actor )
    self.target = actor

    -- if not xx.isBitValue(K_ACTOR_STATE_ATTACK,self.state) then

    -- self:move()
    -- end
end
--[[--
* 获取被攻击列表
]]
function Actor:getTargeted(  )
    return self.targeted
end
--[[--
* 添加攻击者
]]
function Actor:addTargeted( actor )
    table.insert(self.targeted,actor)
end
--[[--
* 我是第几个上ta的人 ,影响攻击时的站位, 以及朝向,考虑team指派
]]
function Actor:setArrNum( num )
    self.arr_num = num
end

function Actor:hurtBy( target )

    if self:isDie() then
        return
    end
    
    local damageval = target.damage

    local str = string.format("-%d",damageval)
    local font = 30
    local isBoom = nil
    --是否暴击
    if isBoom then
        font = 60
    end

    local demageLab = cc.LabelTTF:create(str,"Arial", font)


    if isBoom then
        demageLab:setColor(cc.c3b(0, 255, 0))
    else
        demageLab:setColor(cc.c3b(255, 0, 0))

    end

    --    local x =  math.random()*40
    --    local y =  math.random()*40
    local x, y = 0,0
    demageLab:setPosition(x,y)
   self:getNode():addChild(demageLab)
    local scale = cc.ScaleTo:create(5,0.5)
    local fade = cc.FadeOut:create(0.5)
    local removeSelf = cc.RemoveSelf:create()
    demageLab:runAction(cc.Sequence:create(cc.Spawn:create(scale,fade),removeSelf,nil))
    --    local f = self.blood / totalBlood
    --    self:setPercentage(f*100)

    self.blood = self.blood - damageval

    if self.blood < 0 then
        self:setDie(true)
    end
end

--[[--
-- 1.如果是未接近目标的时候,切换成run的状态,接近目标(如果是目标第二个攻击者应该设置成另一个方向的目标)
-- 寻找目标修正的目的,直接去到目的点再开战
* @param
* @return
]]
function Actor:moveOrAttack(   )
    -- 关于cocos2dx的世界坐标和相对坐标

    local sp = self:getNode()
    local ta = self.target:getNode()

    local offset =  Actor:getTargetPosition(sp,ta)
    local pos = cc.pAdd(offset,k_attacking_pos[self.arr_num])

    --判断是否到达目的地
    local distence = math.sqrt(math.pow(offset.x,2) + math.pow(offset.y,2))
    distence = 1
    cclog("self.range = %d  distence = %d",self.range , distence)
    if self.range > distence then
        -- if sp:getPositionX() == pos.x and sp:getPositionY() == pos.y then
        --到达攻击位置,切换成攻击状态
        if xx.isBitValue(K_ACTOR_STATE_ATTACK,self.state) then
            -- sp:runAction(cc.MoveBy:create(0.2,pos))
            -- todo attack
            cclog(self.id.. "攻击")

        else
            self.state = xx.setBitValue(K_ACTOR_STATE_ATTACK,true,self.state)
            self.state = xx.setBitValue(K_ACTOR_STATE_RUN,false,self.state)

        end
    else
    -- 先不做移动,保持阵型
    --未到达攻击位置,切换成移动状态
    -- if xx.isBitValue(K_ACTOR_STATE_RUN,self.state) then
    --     local time = math.abs(offset.x / self.speed)
    --     -- 判断是否在移动中,不处理操作 jx todo 直接到攻击点位置不需要一步两步,一步两步
    --     cclog("time = " .. time)
    --     -- sp:runAction(cc.MoveBy:create(time,cc.p(self.speed  ,self.speed  )))
    -- else
    --     self.state = xx.setBitValue(K_ACTOR_STATE_ATTACK,false,self.state)
    --     self.state = xx.setBitValue(K_ACTOR_STATE_RUN,true,self.state)

    -- end
    end

end

function Actor:getFixPosition(  )
    return self.fix_pos
end

function Actor:setFixPosition( pos )
    self.fix_pos = pos
    self.state = xx.setBitValue(K_ACTOR_STATE_RUN,true,self.state)
end

function Actor:setFaceAfterFix( flip_arg )
    self.flip_arg = flip_arg
end
--[[--
* 获取两个节点相对的坐标 ,两个节点都转换成世界坐标(忽视锚点),然后对比相差值,再移动
-- 返回的是相对位置,所以要用moveBy移动
* @param
* @return
]]
function Actor:getTargetPosition( sp,ta )
    local a  = sp:convertToWorldSpaceAR(CCP_ZERO)
    local b =  ta:convertToWorldSpaceAR(CCP_ZERO)
    -- ta修正后的坐标fix
    -- local b_fix = cc.pAdd(ta:getFixPosition(),b)
    -- cclog("a %d,%d" ,a.x ,a.y)
    -- cclog("b %d,%d" ,b.x ,b.y)
    -- cclog("cc.pSub(b,a) = %d,%d" ,cc.pSub(b,a).x ,cc.pSub(b,a).y)

    return cc.pSub(b,a)
end

function Actor:getTarget(  )
    return self.target
end

--[[--
* 待机状态,没找到攻击目标的状态,此时不攻击,也不奔跑,
* @param
* @return
]]
function Actor:stand(  )

    if xx.isBitValue(K_ACTOR_STATE_ATTACK,self.state) then
        -- 如果是攻击状态的话,切换成不攻击
        self.state = xx.setBitValue(K_ACTOR_STATE_ATTACK,false,self.state)
    end

    if xx.isBitValue(K_ACTOR_STATE_RUN,self.state) then
        -- 如果是Run状态的话,切换成不Run
        self.state = xx.setBitValue(K_ACTOR_STATE_RUN,false,self.state)
    end

    if not xx.isBitValue(K_ACTOR_STATE_STAND,self.state) then
        cclog("Actor "..self.id.."采取待机动作")
        self.state = xx.setBitValue(K_ACTOR_STATE_STAND,true,self.state)
        -- todo play stand动作
--        self:getNode():setColor(cc.c3b(255,255,255))
        
    end
end

function Actor:isDie(  )

    return xx.isBitValue(K_ACTOR_STATE_DIE,self.state)
end

--[[--
* 处理死亡预留复活接口
* todo,残留尸体的处理,
* @param  flag 生或死?
* @return
]]
function Actor:setDie(flag)

    cclog("死亡  - " .. self.id)
    -- self:getNode():setColor(cc.c3b(0,0,0))
    --todo 播放死亡动画,一段时间清除尸体
    -- todo 记得retain,removeFromParent() ,不然会拖着尸体移动

    if not flag then
        --todo 复活
        return
    end

    self.state = xx.setBitValue(K_ACTOR_STATE_DIE,flag,self.state)

    self:getNode():removeFromParent()

    -- 从攻击的目标中释放自己 ,<放开攻击的单位>
    if self.target then
        for k,v in pairs(self.target:getTargeted()) do
            if v.id == self.id then
                table.remove(self.target:getTargeted(),k)
            end
        end
    end

    --处理攻击自身的单位
    for k,v in pairs(self:getTargeted()) do
        v.target = nil
    end
end

--[[--
* 技能 预留,英雄的话有技能,也许小兵也会有被动吧,
* @param
* @return
]]
function Actor:skill(skill_id)

end
--[[--
* Actor的isInRange的方法是判断是否到指定位置了
* @param
* @return
]]
function Actor:isInRange(  )

    -- todo 未完成
    return true
end

--[[--
* 未实现,跑到Team命令到的位置
* @param
* @return
]]
function Actor:run(  )

    if not self.target then
        return
    end

    -- local sp =  self:getNode()

    -- sp:stopAllActions()

    -- sp:runAction(cc.MoveTo:create(self.distance / self.speed,cc.p(self.target:getNode():getPosition() )))


end

return Actor
 