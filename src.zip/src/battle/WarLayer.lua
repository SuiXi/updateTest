local War = require("battle.War")

local WarLayer = class("WarLayer", xx.Layer)
local warLayer = warLayer or {}
ccb.warLayer = warLayer

function WarLayer:ctor(  )
	
end

function WarLayer:init( id )
	
	local  proxy = cc.CCBProxy:create()
    --加载ccb文件
    local  node  = CCBReaderLoad("ccb/war_bg.ccbi",proxy,warLayer)
    self:addChild(node)

    -- ============================添加调试框============================

    xx.addDebugTool(self) --调用一次就好
    --添加命令例子
    xx.addCmd("fix",function ()
        cclog("hi,my name is JuhnXu")
        War:fixArmy(1,true)
        War:fixArmy(2,true)
    end)
    xx.addCmd("init",function ()
        cclog("hi,my name is JuhnXu")
        War:init()
    end)
    xx.addCmd("s",function ()
        cclog("hi,my name is JuhnXu")
        War:start()
    end)
    xx.addCmd("snow",function ()
        cclog("hi,my name is JuhnXu")
        self:showWeather(false)
        self:showSnow()
    end)
    xx.addCmd("rain",function ()
        cclog("hi,my name is JuhnXu")
        self:showWeather(false)
        self:showRain()
    end)
    xx.addCmd("remove",function ()
        cclog("hi,my name is JuhnXu")
        self:showWeather(false)
    end)


    --添加默认方法,Ps. function 必须要有cmd参数
    xx.addDefaultCmd( function (cmd)
        cclog("hi,my name is JuhnXu %s" , cmd)
    end)
    -- ============================添加调试框=====end=======================
	return self
end

function WarLayer:create(  )

	local layer = WarLayer.new()
	layer:init(1)	
    -- layer:showSnow()
	return layer
end


    -- ============================天气============================
local emitter = nil

function WarLayer:showRain(  )
    
    emitter = cc.ParticleRain:create()
    self:addChild(emitter, 10)
    local pos_x, pos_y = emitter:getPosition()
    emitter:setPosition(pos_x, pos_y )
    emitter:setLife(4)

    emitter:setTexture(cc.Director:getInstance():getTextureCache():addImage("ccb/particle/fire.png"))
end

function WarLayer:showSnow(  )
    emitter = cc.ParticleSnow:create()
    self:addChild(emitter, 10)
    local pos_x, pos_y = emitter:getPosition()
    emitter:setPosition(pos_x, pos_y )
    emitter:setLife(3)
    emitter:setLifeVar(1)

    -- gravity
    emitter:setGravity(cc.p(0, -10))

    -- speed of particles
    emitter:setSpeed(130)
    emitter:setSpeedVar(30)

    local startColor = emitter:getStartColor()
    startColor.r = 0.9
    startColor.g = 0.9
    startColor.b = 0.9
    emitter:setStartColor(startColor)

    local startColorVar = emitter:getStartColorVar()
    startColorVar.b = 0.1
    emitter:setStartColorVar(startColorVar)

    emitter:setEmissionRate(emitter:getTotalParticles() / emitter:getLife())

    emitter:setTexture(cc.Director:getInstance():getTextureCache():addImage("ccb/particle/snow.png"))

end

function WarLayer:showWeather( flag )

    if flag then
        self:showSnow()
    elseif emitter then
        emitter:removeFromParent()
        emitter = nil
    end
end
    -- ============================天气============================

return WarLayer