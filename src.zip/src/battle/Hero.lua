--[[--
 * 英雄
 * @Author:      JuhnXu
 * @DateTime:    2015-04-05 10:39:14
 ]]
local Hero = class("Hero",require("battle.Actor"))

function Hero:ctor(  )
	
end

function Hero:create( name )
	
end

return Hero