--[[--
* 单位部队(部队用于寻路,以及修正队内成员的位置)
* 队员Actor负责攻击逻辑
* @Author:      JuhnXu
* @DateTime:    2015-04-05 07:43:13
]]
local Army = require("config.Army")
local Actor = require("battle.Actor")
local ActorList = require("config.ActorList")

local Team = class("Team")
local const = require("xx.const")


-- 状态
local K_ACTOR_STATE_RUN = const.BIT_INDEX_1
local K_ACTOR_STATE_DIE = const.BIT_INDEX_2
local K_ACTOR_STATE_HURT = const.BIT_INDEX_3
local K_ACTOR_STATE_STAND = const.BIT_INDEX_4
local K_ACTOR_STATE_ATTACK = const.BIT_INDEX_5
local K_ACTOR_STATE_FULL = const.BIT_INDEX_6

-- 特殊状态,冲锋,暴怒等
local K_ACTOR_STATE_FURG = const.BIT_INDEX_7
local K_ACTOR_STATE_SLOW = const.BIT_INDEX_8
local K_ACTOR_STATE_CHARGE = const.BIT_INDEX_9


-- 队形间隔
local army_offset = 15

function Team:ctor(  )
end

function Team:init( team_id,actor_type,is_enemy ,node)

    -- 队内兵种列表
    self.list = {}
    self.actor_type = actor_type or "qiang" --actor_type 兵种,默认枪"qiang"
    self.army_type =  Army[self.actor_type] --根据type获取队形
    self.is_enemy = is_enemy or false
    self.team_id = team_id or 0

    --状态,初始化设定成待机状态
    self.state = 0
    self:stand()

    self.range = ActorList[self.actor_type].range
    self.speed = ActorList[self.actor_type].speed

    -- 空闲单位编号,用于轮询每个单位
    self.free_index = 1
    self.free_round = 0

    --正在攻击单位,和被攻击单位列表
    self.target = nil
    self.targeted = {}
    self.distance = 9999 --与目标的距离

    -- 一个英雄 todo
    self.hero = nil
    -- ccb传入一个node
    self.sp = node or  cc.Node:create()

    return self
end

function Team:create( team_id,army_type,is_enemy,node )

    local obj = Team.new()

    return obj:init(team_id,army_type,is_enemy ,node)
end

--[[--
* 调整队形  ,可以自定义队形,缺省为默认队形
* @param is_fix_face,是否要修正面朝向,army_type 采用其他队形
* @return
]]
function Team:fix( is_fix_face,army_type )

    army_type = army_type or self.army_type

    cclog("调整阵型 " .. self.team_id)
    local flip_arg = 1

    if self:isEnemy() then
        flip_arg = -1
    end

    for k,actor in pairs(self.list) do
        local pos = army_type[k]
        if pos then
            actor:getNode():stopAllActions()
            -- cclog("goto: %d,%d",pos[1] * army_offset,pos[2]* army_offset)
            --todo 优化路线
            actor:getNode():runAction(
                cc.MoveTo:create(0.2,cc.p(
                    pos[1] * army_offset * flip_arg ,
                    pos[2]* army_offset * flip_arg)))
            -- actor:setFixPosition(cc.p(
            --         pos[1] * army_offset * flip_arg ,
            --         pos[2]* army_offset * flip_arg))
            --修正面朝向
            if is_fix_face then
                actor:setFaceAfterFix(flip_arg)
                actor:getNode():setScaleX(flip_arg)

            end
        else
            cclog("error:找不到位置 army_id=%d,actor_id= %d,",self.team_id,k)
        end
    end
end

--[[--
* 设置兵种数量
* @param   string actor_type,int num
* @return
]]
function Team:setActorNum( num )
    --还需要生成多少兵,或者删减
    local offset = num - #self.list

    if offset == 0 then
        return
    end

    cclog("当前的兵种是:"..self.actor_type)

    local actor = nil
    --增加的情况

    if offset > 0 then

        for i=1,offset do

            actor = Actor:create(self.actor_type)
            if actor then
                -- 添加到左方
                self.list[i] = actor
                self.sp:addChild(actor:getNode())

            end
        end
    end

    --删减的情况
    if offset < 0 then
    -- todo 从最后开始删减? 秒杀? 暂时先不考虑...
    end

end

function Team:getNode(  )
    return self.sp
end

function Team:isEnemy(  )
    return self.is_enemy
end

--[[--
* 根据state采取动作
* @param
* @return
]]
function Team:action( dt )

    -- 1.如果死亡的话不执行更新了
    -- 2.如果是待机状态,并且没找到目标就保持待机吧
    --   2.a如果找到目标的话就切换成run状态
    -- 3.如果是攻击状态的话 就保持攻击
    --  3.a如果目标不存在的话 就切换成待机状态
    -- 4.如果是run状态的话,如果在射程之内,切换成攻击状态
    -- 4.a如果不在射程之内,继续run
    -- 4.b如果run的时候目标死亡了,切换成待机
    if self:isDie() then
        -- 单位已经死亡
        cclog("单位"..self.team_id.."已经死亡")
        return
    end

    -- *.大前提,如果没目标,不断去找目标,如果还是没的话都切换成stand()
    if not self.target then

        xx.war:getTarget(self)
        self:stand() --没目标都要切换成待机状态,就算找到目标也站立一个回合
        return
    end

    --以下都是有目标的====================================================
    --如果是待机状态,a如果找到目标的话就取消待机状态切换成run状态
    if xx.isBitValue(K_ACTOR_STATE_STAND,self.state) then

        self.state = xx.setBitValue(K_ACTOR_STATE_STAND,false,self.state)
        self.state = xx.setBitValue(K_ACTOR_STATE_RUN,true,self.state)

        return
    end

    -- 4.如果是run状态的话,如果在射程之内,取消Run状态切换成攻击状态
    if xx.isBitValue(K_ACTOR_STATE_RUN,self.state) then
        -- 在射程之内
        if self:isInRange() then
            self.state = xx.setBitValue(K_ACTOR_STATE_RUN,false,self.state)
            self.state = xx.setBitValue(K_ACTOR_STATE_ATTACK,true,self.state)
        else --4.a如果不在射程之内,继续run
            self:run()
        end

        return
    end

    -- 3.如果是攻击状态的话 就保持攻击
    if xx.isBitValue(K_ACTOR_STATE_ATTACK,self.state) then
        self:attack()
        return
    end

end
--[[--
* @废弃
]]
function Team:update( dt )

end


--[[--
* 更改死亡状态(预留可能会复活)
]]
function Team:setDie( flag )

    if not flag then
        --todo 复活
        return
    end

    self.state = xx.setBitValue(K_ACTOR_STATE_DIE,flag,self.state)

    self:getNode():removeFromParent()

    -- 从攻击的目标中释放自己 ,<放开攻击的单位>
    if self.target then
        for k,v in pairs(self.target:getTargeted()) do
            if v.team_id == self.team_id then
                table.remove(self.target:getTargeted(),k)
            end
        end
    end

    --处理攻击自身的单位
    for k,v in pairs(self:getTargeted()) do
        v.target = nil
    end
end

function Team:isDie(  )

    return xx.isBitValue(K_ACTOR_STATE_DIE,self.state)
end

--[[--
* 任命攻击
* 让自身的单位攻击另外单位,(预留有可能自身单位也行哦)
* 移动逻辑交给单位自身,攻击也是
* @param      (Actor)actor, target_actor
* @return
]]
function Team:assign(  )

    -- actor:attackWith(target_actor)

    -- self.list[1]:attackWith(self.target.list[1])
    --    self.list[2]:getNode():runAction(cc.JumpBy:create(3,cc.p(0,0),50,5))


    for k,v in pairs(self.list) do

        -- 优先处理死亡单位,把他们从队列中移除
        if xx.isBitValue(K_ACTOR_STATE_DIE,v.state) then

            -- !!!!!!!!!!!!!!!!!这里不要重复setDie只处理删除列表就好!!!!!!!!!!!!!!!!!!!
            table.remove(self.list,k)
            -- bug:可能会有漏了一个单位,但是循环的话应该不会有影响
        else --没死的就要干活!!
            -- cclog("--没死的就要干活!!")
            if not v:getTarget() then
                --判断有没有空闲的单位没攻击目标,攻击该目标
                local freeTarget =  self.target:getFreeTarget()

                v:setTarget(freeTarget)

                if freeTarget then
                    --攻击者变红

                    freeTarget:addTargeted(v)
                    -- 设置自己是第几个上ta的人
                    v:setArrNum(#freeTarget:getTargeted())
                else

                    --攻击者洗白 --自己的状态还是要自己管理好么?
                    -- v:getNode():setColor(cc.c3b(255,255,255))
                    -- v.state = xx.setBitValue(K_ACTOR_STATE_STAND,true,v.state)
                    -- v.state = xx.setBitValue(K_ACTOR_STATE_ATTACK,false,v.state)
                end
            end

            --However,队员更新状态
            v:action()
        end
    end

    -- 独立再循环处理死亡单位,虽然多一次循环,但是不影响之前的循环
    -- for k,v in pairs(self.list) do

    --     if xx.isBitValue(K_ACTOR_STATE_DIE,v.state) then

    --     end
    -- end

    -- cclog("============打印测试====================================")

    -- for k,v in pairs(self.list) do
    --     print(k,v.id)
    --     cclog("编号%d 攻击%d,同时受到攻击数为%d",v.id, v:getTarget().id,#v:getTargeted())
    --     if #v:getTargeted() > 0 then
    --         for k,v in pairs(v:getTargeted()) do
    --             cclog("攻击者是: " .. v.id)

    --         end
    --     end
    --     -- cclog("编号%d 攻击%d,同时受到%d的攻击",v.id, v:getTarget().id,v:getTargeted()[1].id)

    -- end
    -- cclog("================================================")
    -- 判断有没有空闲的单位没攻击目标
    -- 1.先判断人数是否饱和
    -- 2.考虑权重是否优先攻击


end

--[[--
* 获取没被攻击的单位
1.根据free_index的累加逐个访问列表
2.如果有空余的就返回
3.假如该单位没空余了, 而且不是饱和状态
4.再找下一个,不过此时开始记录free_round(找下一个的记录,假如轮询了一遍又回来了,证明是饱和了)
5.假如找到了,free_round清零
]]
function Team:getFreeTarget(  )

    local free_index = self.free_index

    if free_index > #self.list then
        free_index = 1
    end

    local free = self.list[free_index]

    self.free_index = free_index + 1

    if free and #free:getTargeted() < 2 then
        self.free_round = 0
        return free

    elseif xx.isBitValue(K_ACTOR_STATE_FULL,self.state) then

        if self.free_round == #self.list then
            self.state = xx.setBitValue(K_ACTOR_STATE_FULL,true,self.state)
            return nil
        end

        self.free_round = self.free_round + 1
        -- 检测是否饱和
        return self:getFreeTarget()
    end


end

function Team:getTargeted(  )
    return self.targeted
end

--[[--
* 待机状态,没找到攻击目标的状态,此时不攻击,也不奔跑,
* @param
* @return
]]
function Team:stand(  )

    if xx.isBitValue(K_ACTOR_STATE_ATTACK,self.state) then
        -- 如果是攻击状态的话,切换成不攻击
        self.state = xx.setBitValue(K_ACTOR_STATE_ATTACK,false,self.state)
    end

    if xx.isBitValue(K_ACTOR_STATE_RUN,self.state) then
        -- 如果是Run状态的话,切换成不Run
        self.state = xx.setBitValue(K_ACTOR_STATE_RUN,false,self.state)
    end

    if not xx.isBitValue(K_ACTOR_STATE_STAND,self.state) then
        cclog("Team "..self.team_id.."采取待机动作")
        self.state = xx.setBitValue(K_ACTOR_STATE_STAND,true,self.state)
        -- todo play stand动作
        for k,v in pairs(self.list) do
            v:stand()
        end
    end
end

--[[--
* 奔跑一段距离
]]
function Team:run(  )

    if not self.target then
        return
    end

    local sp =  self:getNode()

    sp:stopAllActions()

    sp:runAction(cc.MoveTo:create(self.distance / self.speed,cc.p(self.target:getNode():getPosition() )))

end

--[[--
* 如果达到射程,返回true,否则返回false
]]
function Team:isInRange(  )

    -- 调用的前提是目标存在
    if not self.target then
        return
    end

    local targetX,targetY = self.target:getNode():getPosition()
    local x, y = self:getNode():getPosition()
    self.distance = math.sqrt(math.pow(math.abs(x- targetX),2) + math.pow(math.abs(y - targetY),2))

    if self.range > self.distance then
        -- self.distance = 9999 --重新设置与目标的距离

        return true
    else
        return false
    end

end

--[[--
* 攻击一下,当然不会是自己攻击,是命令队员攻击
]]
function Team:attack(  )


    -- 调用的前提是目标存在
    if not self.target then
        return
    end
    -- 命令队员攻击
    self:assign()

end
--[[--
* 克隆队伍  todo
* @param  team 目标
* @return
]]
function Team:clone( team )

end

return Team