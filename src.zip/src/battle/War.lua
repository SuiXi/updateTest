--[[--
* 战争类,负责战斗中的逻辑处理
* @Author:      JuhnXu
* @DateTime:    2015-04-04 13:03:37
]]
local Army = require("config.Army")
local Actor = require("battle.Actor")
local Team = require("battle.Team")

local War = class("War")
-- all 中唯一的id
local total_team_id = 0

function War:ctor(  )

	--回调事件
	self.events = {}

end
--[[--
 * 调整阵型 @待废弃 
 * @param  list_id 队伍的序号 ,is_l 是否为我方  
 ]]
function War:fixArmy( list_id,is_fix_face)

	local team = self.list_all[list_id]
	team:fix(is_fix_face)
end
 
--[[--
 * 战前准备,初始化兵种  
 ]]
function War:init( war_layer )

		--战斗场景
	self.warLayer = war_layer or self.war_layer
	if not self.warLayer then
		cclog("error :war:init 尚未设置好war_layer")
		return 
	end

	--保存team列表,l_我方,r_敌方,All所有的队伍,team的id唯一
	-- l,r都是无序的,而all是有序的
	self.list_l = {}
	self.list_r = {}
	self.list_all = {} 
	total_team_id = 0

	-- 1.创建战斗对象,添加到warLayer 
	-- =========测试添加一队====================================
	local team = nil
	--我方
	total_team_id = total_team_id + 1
	team = Team:create(total_team_id,"qiang",false)
	table.insert(self.list_l,team)
	self.list_all[total_team_id] = team
	self.warLayer:addChild(team:getNode())
	team:getNode():setPosition(380,120)
	team:setActorNum(16)
	team:fix(true)

	total_team_id = total_team_id + 1
	team = Team:create(total_team_id,"qi",false)
	table.insert(self.list_l,team)
	self.list_all[total_team_id] = team
	self.warLayer:addChild(team:getNode())
	team:getNode():setPosition(380,320)
	-- team:getNode():setPosition(50,50)
	team:setActorNum(16)
	team:fix(true)

	total_team_id = total_team_id + 1
	team = Team:create(total_team_id,"gong",false)
	table.insert(self.list_l,team)
	self.list_all[total_team_id] = team
	self.warLayer:addChild(team:getNode())
	team:getNode():setPosition(380,520)
	team:setActorNum(16)
	team:fix(true)

	total_team_id = total_team_id + 1
	team = Team:create(total_team_id,"qiang",false)
	table.insert(self.list_l,team)
	self.list_all[total_team_id] = team
	self.warLayer:addChild(team:getNode())
	team:getNode():setPosition(180,120)
	team:setActorNum(16)
	team:fix(true)

	total_team_id = total_team_id + 1
	team = Team:create(total_team_id,"qi",false)
	table.insert(self.list_l,team)
	self.list_all[total_team_id] = team
	self.warLayer:addChild(team:getNode())
	team:getNode():setPosition(180,320)
	-- team:getNode():setPosition(50,50)
	team:setActorNum(16)
	team:fix(true)

	total_team_id = total_team_id + 1
	team = Team:create(total_team_id,"gong",false)
	table.insert(self.list_l,team)
	self.list_all[total_team_id] = team
	self.warLayer:addChild(team:getNode())
	team:getNode():setPosition(180,520)
	team:setActorNum(16)
	team:fix(true)

	--敌方
	total_team_id = total_team_id + 1
	team = Team:create(total_team_id,"qi",true)
	table.insert(self.list_r,team)
	self.list_all[total_team_id] = team
	self.warLayer:addChild(team:getNode())
	team:getNode():setPosition(580,120)
	team:setActorNum(16)
	team:fix(true)
 
	total_team_id = total_team_id + 1
	team = Team:create(total_team_id,"qi",true)
	table.insert(self.list_r,team)
	self.list_all[total_team_id] = team
	self.warLayer:addChild(team:getNode())
	team:getNode():setPosition(580,320)
	team:setActorNum(16)
	team:fix(true)
 
	total_team_id = total_team_id + 1
	team = Team:create(total_team_id,"qi",true)
	table.insert(self.list_r,team)
	self.list_all[total_team_id] = team
	self.warLayer:addChild(team:getNode())
	team:getNode():setPosition(580,520)
	team:setActorNum(16)
	team:fix(true)
 
	total_team_id = total_team_id + 1
	team = Team:create(total_team_id,"qi",true)
	table.insert(self.list_r,team)
	self.list_all[total_team_id] = team
	self.warLayer:addChild(team:getNode())
	team:getNode():setPosition(780,120)
	team:setActorNum(16)
	team:fix(true)
 
	total_team_id = total_team_id + 1
	team = Team:create(total_team_id,"qi",true)
	table.insert(self.list_r,team)
	self.list_all[total_team_id] = team
	self.warLayer:addChild(team:getNode())
	team:getNode():setPosition(780,320)
	team:setActorNum(16)
	team:fix(true)
 
	total_team_id = total_team_id + 1
	team = Team:create(total_team_id,"qi",true)
	table.insert(self.list_r,team)
	self.list_all[total_team_id] = team
	self.warLayer:addChild(team:getNode())
	team:getNode():setPosition(780,520)
	team:setActorNum(16)
	team:fix(true)
 
	-- =========测试添加一队====================================
end
--[[--
 * 开始战斗  
 ]]
function War:start(  )
	
    --启动游戏循环
    local list = nil
    
     local event = nil
     
    local function update(dt)
    	cclog("update war.. " .. dt)

        if #self.list_l == 0 or #self.list_r == 0 then
            
            local scheduler = cc.Director:getInstance():getScheduler()
--            scheduler:unscheduleScriptFunc(event)
            scheduler:unscheduleScriptEntry(event)
            cclog("战斗结束")
        end
        
        local list = self.list_l
        --我方
        for key, v in pairs(list) do
        	if #v.list > 0 then
	            v:action(dt)
	        else --处理死亡
	        	v:setDie(true)
	        	table.remove(self.list_l,key)
	        	self.list_all[v.team_id] = nil
	        	v = nil
	        	-- key = key -1
	        end
        end
        

        list = self.list_r
        --敌方
        for key, v in pairs(list) do
           	if #v.list > 0 then
	            v:action(dt)
	        else --处理死亡
	        	v:setDie(true)
	        	table.remove(self.list_r,key)
	        	self.list_all[v.team_id] = nil
	        	v = nil
	        	-- key = key -1
	        end
        end
        
    end
     
    
    local scheduler = cc.Director:getInstance():getScheduler()
    event = scheduler:scheduleScriptFunc(update ,0.5, false)
    
    table.insert(self.events,event)
end
--[[--
 * 设置战斗场景  
 ]]
function War:setWarLayer( layer )
	self.warLayer = layer
end
--[[--
 * 查找目标  ,同时如果查找成功的话就设置目标的被攻击单位
 * @param  attacker 自身队伍 find_type 查找方式(预留)
 * @return   
 ]]
function War:getTarget( attacker, find_type )

	local find_type = find_type or 1
    local list = nil
    
	local list = attacker:isEnemy() and self.list_l or self.list_r
    
    local closest = 99999
    local x, y = attacker:getNode():getPosition()
    local path = 99999
    local target = nil
    
    for key, c in pairs(list) do
        path = math.abs(c:getNode():getPositionX() - x) + math.abs(c:getNode():getPositionY() -y)
        if path < closest  then
            target = c 
            closest = path
        end
        closest = closest > path and  path or closest 	
    end

    if target then --相互记录,也添加该攻击者到目标单位,
    	table.insert(target.targeted , attacker)
    	attacker.target = target
    end

    return target 
end

function War:removeActor(actor)
	
	-- local list = actor:isEnemy() and self.actor_list.r or self.actor_list.l
	-- local c = nil
	-- for key, var in pairs(list) do
	-- 	if var == actor then
	-- 	  table.remove(list,key)
	-- 	  cclog("移除 "..key .. " 剩余 ".. #list)
	-- 	  var:getNode():removeFromParent()
	-- 	  var = nil
	-- 	end
	-- end
end


return War.new()

--[[
1.移植三国war追踪战斗,以部队为单位战斗
2.加入旧刀塔心跳计算方式,
3.解决误区,寻路是针对部队的,战斗是针对Actor的,建立部队独立类
]]
