--[[--
 * 消息管理器
 * @Author:      JuhnXu
 * @DateTime:    2015-04-02 17:31:34
 ]]
local MsgHandler = class("MsgHandler")
local Net = require("net.Net")

local GameText = require("lang.GameText")

local isRequestWaiting = false;
local waitingStartTime = 0;		--连接开始时间
local waitTimeOutCount = 0;		--等待超时的次数(超过2次就断掉网络叫玩家重新登录)
	
function MsgHandler:ctor(  )
	
end
--[[--
 * true: 网络连接超时达到上限次数，提示玩家断线  
 ]]
function MsgHandler:checkNetWaitTimeOut(  )
	if waitTimeOutCount < 3 then
		return false
	end
	Net:closeConnect()
		-- UIHandler.toNetWorkError(UIHandler.ERROR_NET_TIME_OUT);

	return true
end

function MsgHandler:processMessage( msg )
	
end
--[[--
 * 处理单个Message，只在MsgHandler里使用  
 * @param     msg 消息体
 * @return    
 ]]
function MsgHandler:handleMessage( msg )
	
	if not msg then
		return false
	end

	local id = msg.id

end
return MsgHandler