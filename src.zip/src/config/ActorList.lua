--[[--
 * 保存兵种的配置
 * @Author:      JuhnXu
 * @DateTime:    2015-04-04 13:38:54
 ]]
return {
    ["qiang"]  = {image = "A1" ,blood = 5,speed = 60,damage = 1,money = 10,range =80 ,time = 0.3},
    ["qi"]  = {image = "A2" ,blood = 3,speed = 80 ,damage = 2 ,money = 20,range =80,time = 0.3},
    ["gong"]  = {image = "A3" ,blood = 2,speed = 40 ,damage = 3 ,money = 20,range =400,time = 0.3},

    ["A4"]  = {image = "A4" ,blood = 2000,speed = 60 ,damage = 40 ,money = 20,range =50,time = 0.3},
    ["A5"]  = {image = "A4" ,blood = 2000,speed = 60 ,damage = 40 ,money = 20,range =50,time = 0.3},
    ["A6"]  = {image = "A4" ,blood = 2000,speed = 60 ,damage = 40 ,money = 20,range =50,time = 0.3},
    ["A7"]  = {image = "A4" ,blood = 2000,speed = 60 ,damage = 40 ,money = 20,range =50,time = 0.3},
    ["A8"]  = {image = "A4" ,blood = 2000,speed = 30 ,damage = 40 ,money = 20,range =50,time = 0.3},
    ["A9"]  = {image = "A4" ,blood = 2000,speed = 30 ,damage = 40 ,money = 20,range =50,time = 0.3},
    ["A10"]  = {image = "A4" ,blood = 2000,speed = 30 ,damage = 40 ,money = 20,range =50,time = 0.3},
   
    ["B1"]  = {image = "B1" ,blood = 1000,speed = 50,damage = 10,money = 10,range =5,time = 0.3},
    ["B2"]  = {image = "B2" ,blood = 2000,speed = 50 ,damage = 30 ,money = 20,range =100,time = 0.3},
    ["B3"]  = {image = "B3" ,blood = 2000,speed = 150 ,damage = 40 ,money = 20,range =5,time = 0.3},
    ["B4"]  = {image = "B4" ,blood = 2000,speed = 50 ,damage = 20 ,money = 20,range =5,time = 0.3},
    ["Hero1"] = {image = "Hero1" ,blood = 1000,speed = 80 ,damage = 50 ,money = 100,range =5,time = 0.3},
    ["Hero2"] = {image = "Hero2" ,blood = 1000,speed = 150 ,damage = 100 ,money = 100,range =5,time = 0.3},
}
 