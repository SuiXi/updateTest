--[[--
 * 英文
 * @Author:      JuhnXu
 * @DateTime:    2015-04-02 17:44:56
 ]]

return 
{
	 ["请稍候..."] = "please wait...",
	 ["你好"]		 = "hello",
}
 