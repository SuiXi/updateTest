local TestLaye = class("TestLaye",xx.Layer)

function TestLaye:init(  )
	print("----------------TestLaye;init-------------")
	return true
end

return TestLaye