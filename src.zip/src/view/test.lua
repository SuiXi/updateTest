

local Test = class("Test",xx.Layer)
return Test