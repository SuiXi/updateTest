

local Test = class("Test",xx.Layer)

function Test:init(  )
	local sp = cc.Sprite:create("bg_big.png")
	sp:setPosition(480,320)
	self:addChild(sp)
end
return Test