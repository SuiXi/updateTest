

local Test = class("Test",xx.Layer)

function Test:init(  )
	local function closePopUp(tag, sender)
        xx.Scene:popLayer()
    end
    local closeItem = cc.MenuItemFont:create("close")
    closeItem:registerScriptTapHandler(closePopUp)
    closeItem:setPosition(900,600)

    local closeMenu = cc.Menu:create(closeItem)
    closeMenu:setAnchorPoint(cc.p(0.0, 0.0))
    closeMenu:setPosition(cc.p(0.0, 0.0))

    self:addChild(closeMenu)
    
	local sp = cc.Sprite:create("bg_big.png")
	sp:setPosition(480,320)
	self:addChild(sp)
	return true
end

return Test