require "CCBReaderLoad"

local MainScene = class("MainScene", function ()
	return cc.Layer:create()
end)

--一个ccb的索引,保持字节点的指针
layerIndex = layerIndex or {}
ccb.layerIndex = layerIndex

local function onButtonTestClicked()
    cclog("CCBButtionTest");
    local scene  = cc.Scene:create()
    local  proxy = cc.CCBProxy:create()
    --加载ccb文件
    local  node  = CCBReaderLoad("MainScene.ccbi",proxy,layerIndex)
    local  layer = node

    return layer
end


local function onPressButton()
    cclog("click")
end

layerIndex.onPressButton = onPressButton


function MainScene:ctor()

    local root_node = onButtonTestClicked() --获取ccb文件的node
    self:addChild(root_node)
     
    --获取并修改子节点
    if layerIndex.helloLabel then 
        layerIndex.helloLabel:setString("Hi,JuhnXu")
    end
 
        
end



return MainScene