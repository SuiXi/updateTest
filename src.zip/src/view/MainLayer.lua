--[[--
* 主城

* @Author:      Seven
* @DateTime:    2015-04-08 23:00:16
]]

local MainLayer = class("MainLayer", xx.Layer)

function MainLayer:init(  )
	local function enterWar(tag, sender)
		-- local layer = require("battle.WarLayer"):create()
  --       xx.Scene:pushLayer(layer)
  --       xx.war = require("battle.War")
	 --    xx.war:init(layer)
     cc.Scene:pushLayer(require("view.test"):create())
    end
    local closeItem = cc.MenuItemFont:create("开始战斗")
    closeItem:registerScriptTapHandler(enterWar)
    -- closeItem:setPosition(900,600)

    local closeMenu = cc.Menu:create(closeItem)
    -- closeMenu:setAnchorPoint(cc.p(0.0, 0.0))
    closeMenu:setPosition(cc.p(480,320))

    self:addChild(closeMenu)

    return true
end

return MainLayer
