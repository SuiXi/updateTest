

local Net = require("net.Net")

local MainLayer = class("MainLayer",function ()
    return cc.Layer:create()
end)

function MainLayer:ctor()


    --一键主场景
    local item_font = cc.MenuItemFont:create("链接sockect")
    item_font:setColor(cc.c3b(255,0,0))
    local menu = cc.Menu:create()
    menu:addChild(item_font)
    self:addChild(menu)
    menu:setPosition(200,200)

    local function menuCallback()
        --        hw.Scene:PopLayer()
        --        hw.Scene:PushLayer(require("view.main_view"):create())
        print("链接sockect")
        Net:openLoginServer()
        --        hw.curLayer:addChild(cc.Sprite:create("item.png"))
    end
    item_font:registerScriptTapHandler(menuCallback)



    --发送
    local item_font = cc.MenuItemFont:create("发送信息sockect")
    item_font:setColor(cc.c3b(255,0,0))
    local menu = cc.Menu:create()
    menu:addChild(item_font)
    self:addChild(menu)
    menu:setPosition(200,100)

    local function menuCallback()
        --        hw.Scene:PopLayer()
        --        hw.Scene:PushLayer(require("view.main_view"):create())
        print("发送信息sockect")
        -- assert(sock:send("hello" .. "\n"))
        --        hw.curLayer:addChild(cc.Sprite:create("item.png"))
        -- Socket.send("s","hi---A\n")
--        Net:openLoginServer()
    end
    item_font:registerScriptTapHandler(menuCallback)

    --==调试代码=======================================
    xx.addDebugTool(self)
    xx.addCmd("close",function ()
        -- Socket.send("s","sd---")
        Net:closeConnect()
    end)
    xx.addCmd("xx",function ()
        Net:sendMsg(1,"s","abcd")
    end)
    xx.addCmd("aa",function ()
        Net:sendMsg(2,"s","abc\ndef\ndd")
    end)
    xx.addCmd("bb",function ()
        Net:sendMsg(1,"s","abc\ndef\n")
    end)
    xx.addCmd("b",function ()
        Net:send("ihilci",1,2,3,200,'a',5)
    end)
    --==调试代码=======================================
    return true
end



bpack=string.pack
bunpack=string.unpack

-- fmt: one or more letter Codes string
-- A  : string
-- c  : char
-- b  : byte (unsigned char)
-- h  : short
-- H  : unsigned short
-- i  : int
-- I  : unsigned int
-- l  : long
-- L  : unsigned long
-- function Socket.send(fmt, ...)
--     --格式码之前加多个s,发送的时候也附带格式码,在服务器获取的时候要首先接受一个s先,
--     fmt = "s"..fmt
--     local msg  = string.pack(fmt,fmt, ...)
--     print("pack---------")
--     print("send msg "..hex(msg))
--     sock:send(msg)
--     sock:send("\n") --发送socket完毕记得发多一个\n表示结束

--     print("unpack---------")
--     local msg_unpack = ""
--     local msg_unpack = {string.unpack(fmt,msg)}
--     for key, var in pairs(msg_unpack) do
--         if type(var) == "string" then
--             print("string = " .. tostring(var))
--         else
--             print("msg = " .. var)
--         end
--     end
--     --    print("msg = " .. tostring(msg_unpack))
--     --    print("a = " .. tonumber(a or 0))
--     --    print("b = " .. tonumber(b or 0))
--     --    print("fmt = " .. fmt)
--     --    for c in (fmt .. '\0'):gmatch('.') do
--     --        print("c = " .. c)
--     --    end


--     -------------------示例--------------------
--     --
--     print("-======================================")

--     --    a=bpack("sbs","my name is ",5*16+1 ,"JuhnXu")
--     --    print(hex(a),string.len(a))
--     --    print(string.unpack("sbs",a))
--     print("-======================================")
--     -------------------示例--------------------

-- end

return MainLayer