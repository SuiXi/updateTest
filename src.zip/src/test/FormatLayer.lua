--[[--
* 队形调试

* @Author:      Seven
* @DateTime:    2015-06-11 16:37:16
]]

local FormatLayer = class("FormatLayer",xx.Layer)

local TeamFormatControl = require("War.TeamFormatControl")
local War = require("War.War")
local Team = require("War.Team")
local Format = require("War.TeamFormat")

function FormatLayer:create(  )
	return FormatLayer.new()
end

function FormatLayer:ctor(  )
	self._bg = cc.Sprite:create("1.jpg")
	self._bg:setAnchorPoint(0,0)
	self:addChild(self._bg)

	--抛射物层
	self._guangQiuNode = cc.Node:create()
    self._bg:addChild(self._guangQiuNode)
    self._guangQiuNode:setLocalZOrder(2000)

    self._arrowNode = cc.Node:create()
    self._bg:addChild(self._arrowNode)
    self._arrowNode:setLocalZOrder(2000)

    --信息层
    self._infoNode = cc.Node:create()
    self._bg:addChild(self._infoNode)
    self._infoNode:setLocalZOrder(2001)

    xx.war = War:create(self)
    xx.war:init({},{})

    self._position = cc.p(480,320)

    local data = xx.war:getHeroData({id = 12111,level = 1,soldierNum = 16})
	self._team = Team:create(data,self._position,const.LEFT)

	self._moveUnit = self._team._hero

	self._move = false
	self._moveTo = cc.p(900,320)

	self:touch()
	self:editBox()
	local scheduler = cc.Director:getInstance():getScheduler() 
	local event = scheduler:scheduleScriptFunc(xx.handler(self,self.spriteLocationUpdate),0.0, false)
end

function FormatLayer:spriteLocationUpdate( dt )
	if self._team then
		self._team._stage = const.IDLE
		self._team:updateUnitSprite(dt)

		self:updateTeamMove(dt)
	end
end

function FormatLayer:updateTeamMove(dt)
	if not self._move then
		return
	end

	local dist = cc.pGetDistance(self._team._position,self._moveTo)
	if dist <= self._team._atkRange then
		self._move = false
		return
	end

	local moveDist = self._team._speed*dt
	local dx = self._moveTo.x - self._team._position.x
	local dy = self._moveTo.y - self._team._position.y
	local mul = moveDist/dist
	self._team._deltaP.x = dx*mul
	self._team._deltaP.y = dy*mul

	self._team._position.x = self._team._position.x + self._team._deltaP.x
	self._team._position.y = self._team._position.y + self._team._deltaP.y

	self._team:setPosition(self._team._position)
end

function FormatLayer:addZQL()
	local data = xx.war:getHeroData({id = 12611,level = 1,soldierNum = 16})
	self._team = Team:create(data,self._position,const.LEFT)
end

function FormatLayer:addQQL()
	local data = xx.war:getHeroData({id = 12511,level = 1,soldierNum = 16})
	self._team = Team:create(data,self._position,const.LEFT)
end

function FormatLayer:addQBL()
	local data = xx.war:getHeroData({id = 12111,level = 1,soldierNum = 16})
	self._team = Team:create(data,self._position,const.LEFT)
end

function FormatLayer:addDBL()
	local data = xx.war:getHeroData({id = 12211,level = 1,soldierNum = 16})
	self._team = Team:create(data,self._position,const.LEFT)
end

function FormatLayer:addGBL()
	local data = xx.war:getHeroData({id = 12311,level = 1,soldierNum = 16})
	self._team = Team:create(data,self._position,const.LEFT)
end

function FormatLayer:addFSL()
	local data = xx.war:getHeroData({id = 12411,level = 1,soldierNum = 16})
	self._team = Team:create(data,self._position,const.LEFT)
end

function FormatLayer:addZQR()
	local data = xx.war:getHeroData({id = 12611,level = 1,soldierNum = 16})
	self._team = Team:create(data,self._position,const.RIGHT)
end

function FormatLayer:addQQR()
	local data = xx.war:getHeroData({id = 12511,level = 1,soldierNum = 16})
	self._team = Team:create(data,self._position,const.RIGHT)
end

function FormatLayer:addQBR()
	local data = xx.war:getHeroData({id = 12111,level = 1,soldierNum = 16})
	self._team = Team:create(data,self._position,const.RIGHT)
end

function FormatLayer:addDBR()
	local data = xx.war:getHeroData({id = 12211,level = 1,soldierNum = 16})
	self._team = Team:create(data,self._position,const.RIGHT)
end

function FormatLayer:addGBR()
	local data = xx.war:getHeroData({id = 12311,level = 1,soldierNum = 16})
	self._team = Team:create(data,self._position,const.RIGHT)
end

function FormatLayer:addFSR()
	local data = xx.war:getHeroData({id = 12411,level = 1,soldierNum = 16})
	self._team = Team:create(data,self._position,const.RIGHT)
end

function FormatLayer:moveUnit( key )
	if key > 0 and key < 17 then
        self._moveUnit = self._team._list[key]
    end

    if key == 0 then
    	self._moveUnit = self._team._hero
    end
end

function FormatLayer:reset()
	self._team._position = cc.p(480,320)
	self._team._stage = const.WALK
	TeamFormatControl:changeToStandFormat(self._team)
end

function FormatLayer:cleanTeam()
	self._team._hero:kill()
	for k,v in pairs(self._team._list) do
		v:kill()
	end
	self._team = nil
end

function FormatLayer:printFormatPos()
	local speed = self._team._hero:getConfigData().speed
	local maxT = 0
	local posList = {}

	local standList = Format.LeftStand
	if self._team._armyType == const.RIGHT then
		standList = Format.RightStand
	end

	for i,v in ipairs(self._team._list) do
		local pos = cc.pSub(v:getPosition(),self._team._position)
		local origPos = standList[i]
		local dist = cc.pGetDistance(pos,origPos)
		local t = dist/speed
		if t > maxT then
			maxT = t
		end

		posList[i] = {x = pos.x,y = pos.y,t = t}
	end

	for i,v in ipairs(posList) do
		local t = maxT - v.t
		print("{x = "..v.x..", y = "..v.y..", t = "..t.."},")
	end

	local pos = cc.pSub(self._team._hero:getPosition(),self._team._position)
	local origPos = cc.p(0,0)
	local dist = cc.pGetDistance(pos,origPos)
	local t = maxT - dist/speed

	print("heroPos = {x = "..pos.x..", y = "..pos.y..", t = "..t.."},")

	print("teamMoveTime = "..maxT..",")
end

function FormatLayer:move()
	TeamFormatControl:changeToMoveFormat2(self._team)
	self._move = true
	self._team:setLookingTo(self._moveTo)
end

function FormatLayer:editBox()
	local cmd_box = nil
    cmd_box = cc.EditBox:create(cc.size(174, 69), cc.Scale9Sprite:create("btn_cmd.png"))
    cmd_box:setPosition(cc.p(cc.Director:getInstance():getWinSize().width - 174,50))
    cmd_box:setReturnType(cc.KEYBOARD_RETURNTYPE_DONE )

    local function editBoxTextEventHandle(strEventName,pSender)

        if strEventName == "changed" then
            local cmd = pSender:getText()
            cclog("cmd = " .. cmd)
            if tonumber(cmd) then
            	self:moveUnit(tonumber(cmd))
            else
            	self._moveUnit = nil

            	if cmd == "reset" then
            		self:reset()
       			elseif cmd == "zql" then
       				self:cleanTeam()
       				self:addZQL()
       			elseif cmd == "qql" then
       				self:cleanTeam()
       				self:addQQL()
       			elseif cmd == "qbl" then
       				self:cleanTeam()
       				self:addQBL()
       			elseif cmd == "dbl" then
       				self:cleanTeam()
       				self:addDBL()
       			elseif cmd == "gbl" then
       				self:cleanTeam()
       				self:addGBL()
       			elseif cmd == "fsl" then
       				self:cleanTeam()
       				self:addFSL()

       			elseif cmd == "zqr" then
       				self:cleanTeam()
       				self:addZQR()
       			elseif cmd == "qqr" then
       				self:cleanTeam()
       				self:addQQR()
       			elseif cmd == "qbr" then
       				self:cleanTeam()
       				self:addQBR()
       			elseif cmd == "dbr" then
       				self:cleanTeam()
       				self:addDBR()
       			elseif cmd == "gbr" then
       				self:cleanTeam()
       				self:addGBR()
       			elseif cmd == "fsr" then
       				self:cleanTeam()
       				self:addFSR()

       			elseif cmd == "print" then
       				self:printFormatPos()

       			elseif cmd == "move" then
       				self:move()
            	end
            end
        end
    end

    cmd_box:registerScriptEditBoxHandler(editBoxTextEventHandle)
    self:addChild(cmd_box)
end

function FormatLayer:touch()

	-- 触摸开始
	local function onTouchBegan(touch, event)
		-- print("Touch Began")
		-- local pos = touch:getLocation() -- 获取触点的位置
		-- print(pos.x .. " , " .. pos.y)  -- 输出log
		
		return true                     -- 必须返回true 后边move end才会被处理
	end
	 
	-- 触摸移动
	local function onTouchMoved(touch, event)
		-- print("Touch Moved")
		local pos = touch:getLocation()
		if self._moveUnit then
			self._moveUnit:setPosition(pos)
		end
	end
	 
	-- 触摸结束
	local function onTouchEnded(touch, event)
		-- print("Touch Ended")
		local pos = touch:getLocation() -- 获取触点的位置

		-- print(pos.x .. " , " .. pos.y)  -- 输出log
	end
	 
	-- 注册单点触摸
	local dispatcher = cc.Director:getInstance():getEventDispatcher()
	local listener = cc.EventListenerTouchOneByOne:create()
	 
	listener:registerScriptHandler(onTouchBegan, cc.Handler.EVENT_TOUCH_BEGAN)
	listener:registerScriptHandler(onTouchMoved, cc.Handler.EVENT_TOUCH_MOVED)
	listener:registerScriptHandler(onTouchEnded, cc.Handler.EVENT_TOUCH_ENDED)
	 
	dispatcher:addEventListenerWithSceneGraphPriority(listener, self)
end

function FormatLayer:addUnit( unit )
	self:addChild(unit)
end

function FormatLayer:addGuangQiu( gq )
	if self._guangQiuNode then
		self._guangQiuNode:addChild(gq)
	end
end

function FormatLayer:addArrow( arrow )
	if self._arrowNode then
		self._arrowNode:addChild(arrow)
	end
end

function FormatLayer:addInfo( info )
	if self._infoNode then
		self._infoNode:addChild(info)
	end
end

return FormatLayer