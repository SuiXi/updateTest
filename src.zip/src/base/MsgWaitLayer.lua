--[[--
* 加载界面

* @Author:      Seven
* @DateTime:    2015-04-08 15:43:16
]]

local MsgWaitLayer = class("MsgWaitLayer", xx.Layer)


function MsgWaitLayer:init(  )

    local msg = cc.Label:create()
    msg:setPosition(100,100)
    msg:setString("正在加载中...")
    self:addChild(msg)

    local function onTouchBegan()
        return true
    end
    local listener1 = cc.EventListenerTouchOneByOne:create()
    listener1:setSwallowTouches(true)
    listener1:registerScriptHandler(onTouchBegan,cc.Handler.EVENT_TOUCH_BEGAN )
    --    listener1:registerScriptHandler(onTouchMoved,cc.Handler.EVENT_TOUCH_MOVED )
    --    listener1:registerScriptHandler(onTouchEnded,cc.Handler.EVENT_TOUCH_ENDED )
    local eventDispatcher = self:getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(listener1, self)

    return true

end



return MsgWaitLayer