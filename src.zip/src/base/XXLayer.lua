--[[--
* 基本层

* @Author:      Seven
* @DateTime:    2015-04-08 15:43:16
]]

local XXLayer = class("XXLayer",function ()
    return cc.Layer:create()
end)

function XXLayer:ctor(  )
    self.opened_on_show = true
    self.show = false



end
--创建一个layer的起点方法
function XXLayer:create(  )


    local layer = self.new()

    if layer and layer:init() then

        local function onNodeEvent(event)
            if "enter" == event then
                layer:onEnter()
            elseif "exit" == event then
                layer:onExit()
            end
        end

        layer:registerScriptHandler(onNodeEvent)

        return layer
    end
end

--初始化方法,可以覆盖
function XXLayer:init(  )

    --test=======只是测试使用===================================================================
    --    local menu = cc.Menu:create()
    local function closePopUp(tag, sender)
        xx.Scene:popLayer()
    end
    local closeItem = cc.MenuItemFont:create("close")
    closeItem:registerScriptTapHandler(closePopUp)
    closeItem:setPosition(900,600)

    local closeMenu = cc.Menu:create(closeItem)
    closeMenu:setAnchorPoint(cc.p(0.0, 0.0))
    closeMenu:setPosition(cc.p(0.0, 0.0))

    self:addChild(closeMenu)
    --test==========================================================================

    return true
end
--设置层为可用或者不可用,并将子控件都设置成不可用
function XXLayer:setEnabled( flag )
--继承此方法
--[[--
eg:
self.button:setEnabled(false)
self.scroll_view:setEnabled(false)
]]
    if flag then
        self:resume()
    else
        self:pause()

    end
end

--设置是否显示即为打开
function XXLayer:setOpenedonShow( flag )
    self.opened_on_show = flag
end

--设置显示的时候需要的一些操作
function XXLayer:onShow(  )
    cclog("XXLayer:onShow")
    self.show = true
    self:setVisible(true)
    self:setEnabled(true)

    if self.opened_on_show then
        self:opened()
    end
end
--设置隐藏的时候需要的一些操作
function XXLayer:onHide(  )
    cclog("XXLayer:OnHide")

    self.show = false
    self:setVisible(false)
    --    self:ShowLoading()
    self:setEnabled(false)
end

--设置打开页面的时候需要的一些操作
function XXLayer:opened(  )
    cclog("XXLayer:open")
    --一般是网络请求的操作
end

function XXLayer:isShow(  )
    return self.show
end

function XXLayer:onEnter(  )
    cclog("XXLayer:onEnter")

    self:onShow()
end

function XXLayer:onExit(  )
    cclog("XXLayer:onExit")
    
    self:onHide()

end

--设置上一层的Layer
function XXLayer:setPreviousLayer( layer )
    self.layer = layer
end

--获取上一层的Layer
function XXLayer:getPreviousLayer(  )
    return self.layer
end

--设置所属的场景 暂时不用
function XXLayer:setParentScene( scene )
    self.parentScene = scene
end

--获取所属的场景 暂时不用
function XXLayer:getParentScene(  )
    return self.parentScene
end

--[[--
显示加载界面
]]
function XXLayer:showMsgWait()
    self.loading = require("base.MsgWaitLayer"):create()
    xx.Scene:pushLayer(self.loading)
end

--[[--
隐藏加载界面
]]
function XXLayer:hideMsgWait()

    if self.loading then
        xx.Scene:PopLayer(self.loading)
        self.loading = nil
    end
end


return XXLayer