--[[--
* 基本场景

* @Author:      Seven
* @DateTime:    2015-04-08 15:43:16
]]

local XXScene = class("XXScene",function ()
    return cc.Scene:create()
end)
--XXScene.__index = XXScene

-- /** 每个状态的子状态*/
INIT  = 1;
LOGIC = 2;
CLEAN = 3;
PAINT = 4;

-- /** 游戏的状态 */
XXScene.STAGE_NO_CHANGE     = 0;
XXScene.STAGE_LOGO          = 1;
XXScene.STAGE_INIT          = 2;
XXScene.STAGE_LOCAL_LOGIN   = 3;    --本地测试
XXScene.STAGE_TITLE_MOVIE   = 4;    --标题画面动画

XXScene.STAGE_MAIN_MENU     = 5;    --主菜单

XXScene.STAGE_CHAR_LIST     = 6;    --角色列表
--  XXScene.STAGE_CREATE_CHAR   = 7;    --创建角色
    
    
XXScene.STAGE_GAME_AREA_LINE = 8;   --区和线


function XXScene:ctor(  )
    self.enter = false
    self.gStage = XXScene.STAGE_LOGO
    self.stageCounter = 0 --状态内计数器
--    xx.curLayer = nil

end
--创建一个scene的起点方法
function XXScene:create(  )


    local scene = self.new()

    if scene and scene:init() then


        local function onNodeEvent(event)
            if "enter" == event then
                scene:onEnter()
            elseif "exit" == event then
                scene:onExit()
            end
        end

        scene:registerScriptHandler(onNodeEvent)

        return scene
    end
end

--初始化方法,可以覆盖
function XXScene:init(  )
    return true
end

function XXScene:onEnter(  )
    cclog("XXScene:onEnter")
    if xx.curLayer then
        --通知除最表面一层的其他自定义层隐藏
        local layer = xx.curLayer:getPreviousLayer()

        while layer do
            layer:onHide()
            layer = layer:getPreviousLayer()
        end

        xx.curLayer:onShow()
    end
    self.enter = true
end

function XXScene:onExit(  )


end

--获取当前最表面的层
function XXScene:GetRunningLayer(  )
    return xx.curLayer
end



--替换当前最表面的层
function XXScene:replaceLayer( layer )
    self:popLayer()
    self:pushLayer(layer)
end

--增加层到表面 is_ui是用来压入ui层不隐藏当前层
function XXScene:pushLayer( layer )
    is_ui = is_ui or false

    if xx.iskindof(layer,"XXLayer") then

        layer:setParentScene(self)

        if xx.curLayer then
            if not xx.iskindof(layer,"UIHandler") then
                xx.curLayer:onHide()
            end
            layer:setPreviousLayer(xx.curLayer)
        end

        xx.curLayer = layer
        
        self:addChild(xx.curLayer)

        if self.enter then
            layer:onShow()
        end
    else
        cclog("传入的layer不是XXLayer")
    end
end

--移除层
function XXScene:popLayer( layer )

    if layer and layer ~= xx.curLayer then

        local tempLayer = xx.curLayer

        while tempLayer and tempLayer:getPreviousLayer() ~= layer do
            tempLayer = tempLayer:getPreviousLayer()
        end

        if tempLayer then
            self:removeChild(layer)
            tempLayer:setPreviousLayer(layer:getPreviousLayer())
        end

    elseif xx.curLayer then

        local temp = xx.curLayer:getPreviousLayer()

        xx.curLayer:setPreviousLayer(nil)
        --        xx.curLayer:pause()
        -- TODO 这里存在问题,加入修改过的框架后会报错

--        xx.curLayer:removeFromParent() --uiButton删除的时候会多调用一下release方法导致崩溃
        xx.curLayer:runAction(cc.RemoveSelf:create()) --移除自身的话最好用runAction

        xx.curLayer = temp

        if xx.curLayer then
            xx.curLayer:onShow()
 
        end
    end
end

--[[--
 * 程序更新的主循环  
 ]]
function XXScene:logic(  )
    --检查Socket心跳
    MsgManager:doSocketHeart()
        
    --检查新手指引
    --todo
    --游戏中信息处理
    --todo
    --UI逻辑处理
    --todo

    local newStage = self.gStage
    local tempkey = self.gkey --游戏按键暂时无用

    newStage = doStage(self.gStage ,XXScene.LOGIC,tempkey)

    if newStage ~= XXScene.STAGE_NO_CHANGE and newStage ~= self.gStage then
        self:doStage(gStage,CLEAN,0)
        gStage = newStage
        self:doStage(gStage,INIT,0)

    end

end

--[[--
 * 做游戏状态机  
 ]]
 function XXScene:doStage( stage, step, key )
     local nextStage = XXScene.STAGE_NO_CHANGE

     if step == XXScene.LOGIC then

        local controlStage = GameWorld:executeGlobalControlList()
        if controlStage ~= XXScene.STAGE_NO_CHANGE and controlStage ~= self.stage then
            return controlStage
        end

        --输入信息处理
     end


     if stage == XXScene.STAGE_LOGO then
        nextStage = self:doGameLogo(step , key)

    elseif stage == XXScene.STAGE_WORLD then
        nextStage = self.doWorld(step,key)

    end


    return nextStage

 end
          

    --     switch(stage)
    --     {
    --     case STAGE_QUIT:
    --         //这里会执行一次step = init才会退出游戏
    --         break;
    --     case STAGE_ERROR:
    --         nextStage = doError(step,key);
    --         break;
    --     case STAGE_LOGO:
    --         nextStage = doGameLogo(step,key);
    --         break;
    --     case STAGE_INIT:
    --         nextStage = doGameInit(step,key);
    --         break;
    --     case STAGE_WORLD:
    --         nextStage = doWorld(step,key);
    --         break;
    --     //#ifndef LOW
    --     case STAGE_ARENA_START:
    --         nextStage = doArenaStart(step, key);
    --         break;
    --     case STAGE_ARENA:
    --         nextStage = doArena(step, key);
    --         break;
    --     case STAGE_TEAM_BOSS_START:
    --         nextStage = doTeamBossStart(step, key);
    --         break;
    --     case STAGE_TEAM_BOSS:
    --         nextStage = doTeamBoss(step, key);
    --         break;
    --     //#endif
    --     case STAGE_SKY_ARENA_START:
    --         nextStage = doSkyArenaStart(step, key);
    --         break;
    --     case STAGE_SKY_ARENA:
    --         nextStage = doSkyArena(step, key);
    --         break;
    --     case STAGE_COUNTRY_WAR_START:
    --         nextStage = doCountryWarStart(step, key);
    --         break;
    --     case STAGE_COUNTRY_WAR:
    --         nextStage = doCountryWar(step, key);
    --         break;
    --     case STAGE_WORLD_MAP:
    --         nextStage = doWorldMap(step, key);
    --         break;
    --     case STAGE_BATTLE_START:
    --         nextStage = doBattleStart(step,key);
    --         break;
    --     case STAGE_BATTLE:
    --         nextStage = doBattle(step,key);
    --         break;
    --     case STAGE_MAIN_MENU:
    --         nextStage = doMainMenu(step, key);
    --         break;
    --     case STAGE_GAME_AREA_LINE:
    --         nextStage = doServerList(step, key);
    --         break;
    --     case STAGE_TITLE_MOVIE:
    --         nextStage = doTitleMovie(step, key);
    --         break;
    --     case STAGE_CHAR_LIST:
    --         nextStage = doCharList(step, key);
    --         break;
    --     case STAGE_LOGIN_WAIT:
    --         nextStage = doLoginWait(step, key);
    --         break;
    --     case STAGE_JUMP_MAP_WAIT:
    --         nextStage = doJumpMapWait(step, key);
    --         break;
    --     case STAGE_CONN_WORLD:
    --     case STAGE_CONN_WORLD_CHECK:
    --         nextStage = doConnWorld(step, key,stage==STAGE_CONN_WORLD_CHECK);
    --         break;
    --     case STAGE_MAP_IMAGE:
    --     case STAGE_LOGIN_MAP_IMAGE:
    --         nextStage = doMapImage(step, key, stage==STAGE_LOGIN_MAP_IMAGE);
    --         break;
            
    --     //#ifdef DEBUG
    --     case STAGE_ICON_TEST:
    --         nextStage = doIconTest(step,key);
    --         break;
    --     case STAGE_BATTLE_TEST_2:
    --         nextStage = doBattleTest2(step,key);
    --         break;
    --     case STAGE_BATTLE_TEST_3:
    --         nextStage = doBattleTest3(step,key);
    --         break;
    --     case STAGE_BATTLE_TEST:
    --         nextStage = doBattleTest(step,key);
    --         break;
    --     case STAGE_LOCAL_LOGIN:
    --         nextStage = doLocalLogin(step,key);
    --         break;
    --     case STAGE_LOCAL_MENU:
    --         nextStage = doLocalMenu(step,key);
    --         break;
    --     //#endif
            
    --     }
        
    --     return nextStage;
    -- }
    


--     // ==========================游戏Logo状态=================================== //
--     /**每个Logo播放的时间*/
local DELAY_LOGO         = 2000;
--     //logo的最大数量(0,1,2,3)
local LOGO_NUM = 3;

function XXScene:doGameLogo( step , key )

    if step == INIT then

    elseif step == LOGIC then

    elseif step == CLEAN then

    elseif step == PAINT then

    end

    return XXScene.STAGE_NO_CHANGE
end 
    


    -- doWorld
function XXScene:doWorld( step , key )
    
    if step == INIT then
        --创建世界地图UI
        if WorldPanel.gameworldPanelUI == nil then

        end
    end

    return XXScene.STAGE_NO_CHANGE
end
 
    
return XXScene:create()