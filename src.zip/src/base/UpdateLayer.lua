--[[--
* 热更资源

* @Author:      Seven
* @DateTime:    2015-04-09 14:20:16
]]

local UpdateLayer = class("UpdateLayer", xx.Layer)

local targetPlatform = cc.Application:getInstance():getTargetPlatform()

local lineSpace = 40
local itemTagBasic = 1000
local menuItemNames =
{
    "enter",
    "reset",
    "update",
}

local winSize = cc.Director:getInstance():getWinSize()

function UpdateLayer:init()
    self:update()
    return true
end

function UpdateLayer:onExit()
    
end

function UpdateLayer:update()

    local support  = false
    if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) 
        or (cc.PLATFORM_OS_WINDOWS == targetPlatform) or (cc.PLATFORM_OS_ANDROID == targetPlatform) 
        or (cc.PLATFORM_OS_MAC  == targetPlatform) then
        support = true
    end

    if not support then
        print("Platform is not supported!")
        return
    end

    local isUpdateItemClicked = false
    local assetsManager       = nil
    local pathToSave          = ""

    local menu = cc.Menu:create()
    menu:setPosition(cc.p(0, 0))
    cc.MenuItemFont:setFontName("Arial")
    cc.MenuItemFont:setFontSize(24)

    local progressLable = cc.Label:createWithTTF("","fonts/arial.ttf",30)
    progressLable:setAnchorPoint(cc.p(0.5, 0.5))
    progressLable:setPosition(cc.p(140,200))
    self:addChild(progressLable)

    pathToSave = createDownloadDir()
   
    local function onError(errorCode)
        if errorCode == cc.ASSETSMANAGER_NO_NEW_VERSION then
            progressLable:setString("no new version")
        elseif errorCode == cc.ASSETSMANAGER_NETWORK then
            progressLable:setString("network error")
        end
    end

    local function onProgress( percent )
        local progress = string.format("downloading %d%%",percent)
        progressLable:setString(progress)
    end

    local function onSuccess()
        progressLable:setString("downloading ok")
        cc.FileUtils:getInstance():addSearchPath("src")
        local TLayer = require("view.test")

        xx.Scene:pushLayer(TLayer:create())

        print("createDownloadDir()"..createDownloadDir())
    end

    local function getAssetsManager()
        if nil == assetsManager then
            assetsManager = cc.AssetsManager:new(
                    "http://qd.baidupcs.com/file/c669bbc159a39b0d1ca4ea236a9dfd14?bkt=p2-nb-971&fid=1481445575-250528-229075123657429&time=1428570167&sign=FDTAXERLBH-DCb740ccc5511e5e8fedcff06b081203-3rRh4biLt5Wsu9RO7EUwLY1TA5w%3D&to=qb&fm=Nin,B,T,t&newver=1&newfm=1&flow_ver=3&sl=79429708&expires=8h&rt=pr&r=263245757&mlogid=1019896153&vuk=1481445575&vbdid=3086532815&fin=src.zip&fn=src.zip",
                    "http://localhost/MyService/Service.php",
                    pathToSave
                )
            assetsManager:retain()
            assetsManager:setDelegate(onError, cc.ASSETSMANAGER_PROTOCOL_ERROR )
            assetsManager:setDelegate(onProgress, cc.ASSETSMANAGER_PROTOCOL_PROGRESS)
            assetsManager:setDelegate(onSuccess, cc.ASSETSMANAGER_PROTOCOL_SUCCESS )
            assetsManager:setConnectionTimeout(3)
        end

        return assetsManager
    end

    local function update(sender)
        progressLable:setString("")

        getAssetsManager():update()
    end

    local function reset(sender)
        progressLable:setString("")

        deleteDownloadDir(pathToSave)

        getAssetsManager():deleteVersion()

        createDownloadDir()
        print("------pathToSave ="..createDownloadDir())
    end

    local function reloadModule( moduleName )

        package.loaded[moduleName] = nil

        return require(moduleName)
    end

    local function enter(sender)

        if not isUpdateItemClicked then
            local realPath = pathToSave .. "/package"
            addSearchPath(realPath,true)
        end

        local WarLayer = reloadModule("src/battle/WarLayer")

        local layer = WarLayer:create()
        xx.Scene:replaceLayer(layer)
        xx.war = require("battle.War")
        xx.war:init(layer)
    end

    local callbackFuncs =
    {
        enter,
        reset,
        update,
    }

    local function menuCallback(tag, menuItem)
        local scene = nil
        local nIdx = menuItem:getLocalZOrder() - itemTagBasic
        local ExtensionsTestScene = CreateExtensionsTestScene(nIdx)
        if nil ~= ExtensionsTestScene then
            cc.Director:getInstance():replaceScene(ExtensionsTestScene)
        end
    end

    for i = 1, table.getn(menuItemNames) do
        local item = cc.MenuItemFont:create(menuItemNames[i])
        item:registerScriptTapHandler(callbackFuncs[i])
        item:setPosition(winSize.width / 2, winSize.height - i * lineSpace)
        if not support then
            item:setEnabled(false)
        end
        menu:addChild(item, itemTagBasic + i)
    end

    local function onNodeEvent(msgName)
        if nil ~= assetsManager then
            assetsManager:release()
            assetsManager = nil
        end
    end

    self:registerScriptHandler(onNodeEvent)

    self:addChild(menu)
end

return UpdateLayer