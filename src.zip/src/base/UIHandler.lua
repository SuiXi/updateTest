--[[--
* UI层

* @Author:      Seven
* @DateTime:    2015-04-08 20:47:16
]]

local UIHandler = class("UIHandler", xx.Layer)

function UIHandler:onEnter(  )
	self:showMask()
end

function UIHandler:onExit(  )
	self:hideMask()
end

-- 添加遮罩
function UIHandler:showMask(  )
	self.mask = cc.LayerColor:create( cc.c4b(0, 255, 255, 10) )
	self:addChild(self.mask)
end

function UIHandler:hideMask(  )
	self.mask:setVisible(false)
end

return UIHandler