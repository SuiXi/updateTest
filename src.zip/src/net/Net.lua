require("net.lpack")

--[[--
* 网络相关接口
* @Author:      JuhnXu
* @DateTime:    2015-02-13 16:49:07
]]
local Net = {}

local socket = require("socket")

local host = "127.0.0.1"
local port = 8080
local sock = nil            --socket的实例
local _is_accepting = false --是否正在接收着信息
local _waitting_time = 0         --当前时间
local _sleep_time = 0.3     --监听网络间隔时间
local IS_SHORT_CONNECT = false --是否短链接

local IS_NET_DEBUG = true

--重写全局cclog,加入判断
local cclog = function(...)
    if IS_NET_DEBUG then
        print(string.format(...))
    end
end

--[[--
* 等待消息的队列,结构是[id] = {cb,forever}
]]
local waittingList = {}

--[[--
* socket连接
* @param  ip
* @return bool 是否成功
]]
function Net:connect( ip )

    local version = "v1.0"
    self._reconnecting = true
    --先关闭连接
    self:closeConnect()
    --获取当前时间
    sock = socket.try(socket.connect(host, port))

    if sock then
        self.connTime = socket.gettime()
        -- do stuff
        cclog(self.connTime .. " seconds elapsed")
        sock:settimeout(0)
        return true
    end

    return false

end

--[[--
* 连接登录服,对外提供连接接口
]]
function Net:openLoginServer(  )
    return Net:connect(ip)
end
--[[--
* 关闭socket连接
]]
function Net:closeConnect(  )
    if sock then
        sock:close()
        sock = nil
    end
end

--[[--
* 发送数据包
* @param   id 协议号, fmt 格式码, ... 数据

-- fmt: 格式码
-- s  : string
-- i  : int
-- b  : byte (unsigned char)

-- c  : char
-- h  : short
-- H  : unsigned short
-- I  : unsigned int
-- l  : long
-- L  : unsigned long
]]
function Net:sendMsg(id, fmt , ...)

    if IS_SHORT_CONNECT then --短链接的话发送消息之前都要开启socket,发送完要关闭
        Net:openLoginServer()
    end

    --前缀发送 协议号 和 格式码
    fmt = "i"..fmt --加入协议号打包成[数据]部分
    local msg  = string.pack(fmt,id, ...)
    cclog("发送头部信息 : \n "..hex(msg) .." ,len = " .. #msg)

    fmt = "i"..fmt --加入数据部分的长度,组成包的头部,再次打包
    msg = string.pack(fmt,#msg , id , ...)

    cclog("发送完整消息体 [head + body]: \n "..hex(msg) .."len = " .. #msg)

    --发送消息体
    sock:send(msg)
    --发送socket完毕记得发多一个\n表示结束
    sock:send("\n")

    cclog("客户端发送协议: "..id)

    if IS_SHORT_CONNECT then
        Net:closeConnect()
    end

    return true
end

--[[--
* 注册回调方法,当有消息过来会调用对应方法
* @param  id 协议号,cbFunc回调方法,isForever 是否持续监听
]]
function Net:registMsg( id, cbFunc, isForever )

    local isForever = isForever or false
    waittingList[id] = { cb = cbFunc, forever = isForever or false}
end

--[[--
* 移除协议号 对应的信息监听
* @param     id 协议号
]]
function Net:removeMsg( id )
    waittingList[id] = nil
end

--[[--
* 清空所有的监听
]]
function Net:clearAllMsg(  )
    waittingList = {}
end

--[[--
* 处理回调消息
* @param   data 数据
* @return data作为参数调用id对应的回调方法
]]
function Net:processMsg( data )
    -- todo 改成消息管理器处理
    local res = nil --处理后的数据

    --1.字节长度,2.协议号,3.格式码,4.真实的数据
    local len ,id  = string.unpack(data,"i")

    if id == 1 then

        res = {string.unpack("is",data)}

        --打印数据包括格式码
        cclog("=========data=================")
        for k,v in pairs(res) do
            cclog(k,v)
        end
        cclog("==========================")
    else
        cclog("")
    end

    if not waittingList[id] then
        cclog("没有找到对应的注册消息")
        return
    end

    --传入data到回调函数
    waittingList[id].cb(res)

    --如果不是常驻监听的话,从监听队列移除
    if not waittingList[id].forever then
        Net.removeMsg(id)
    end

    return true
end
--recvt接收长度, sendt,status接受状态, data当前的数据包,receive_status当前端口接受状态
local recvt, sendt, status,data,receive_status

--[[--
* 继续接收未完的消息
* @param
* @return
]]
function Net:continueRec( total_len )

    cclog("接受服务器信息 协议: 当前接收到数据长度是 "..#data)

    local un_recive_len = total_len - #data
    cclog("还有 "..un_recive_len.."未接收")

    if un_recive_len <= 0 then
        cclog("消息已经接收完毕")
        return
    end

    --继续接收
    local un_recive = sock:receive()
    -- cclog("un_recive = " .. #un_recive)
    -- cclog("data = " .. hex(data))
    -- cclog("un_recive = " .. hex(un_recive))
    data = data .."\n".. un_recive
    cclog("当前接收到的数据 data = " .. hex(data))

    Net:continueRec(total_len,data)
end
--[[--
* 网络的核心循环,接收信息
* @param
* @return
]]
function Net:logic( dt )

    if not sock then
    
        return false
    end
    
    _waitting_time = _waitting_time + dt
    if _waitting_time < _sleep_time then
        return
    end
--    cclog("_waitting_time = " .. _waitting_time)
    --清空等待时间
    _waitting_time = 0

    recvt, sendt, status = socket.select({sock}, nil, 1)

    if #recvt > 0 then

        if not _is_accepting then --正在接收数据中

            data, receive_status = sock:receive()

            if receive_status ~= "closed" then

                if data then

                    _is_accepting = true

                    --len 本体数据长度,id 协议号
                    local _,len , id =  string.unpack(data,"i2")

                    if id == nil then
                        cclog("id 不存在或者不符合格式")
                        return
                    end

                    cclog("接收服务器信息 协议号: "..id .. ",本体长度是 "..len)
                    if len ~= #data -4 then --#data 当前接受到的数据长度,-4去除头部长度,剩下的就是本体数据长度len
                        --循环接收信息
                        self:continueRec(len + 4 )

                    end

                    --todo 根据协议号交给消息管理器进行处理 by JuhnXu
                    ---------------------------消息管理器测试---------------------------------------
                    if id == 1 or id == 2 then --协议号1的消息处理
                        -- Net:sendMsg(1,"s","abcd")
                        cclog("解析前data = " .. hex(data))

                        local fmt = "i2s"
                        local _, len, id ,str = string.unpack(data,fmt)
                        cclog(" 消息包:")
                        print(string.unpack(data,fmt))

                    end
                    --------------------------------end----------------------------------

                    _is_accepting = false
                end
            end
        end
    end
end

return Net